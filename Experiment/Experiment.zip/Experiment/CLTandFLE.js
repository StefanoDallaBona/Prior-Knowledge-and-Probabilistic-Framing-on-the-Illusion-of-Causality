﻿/****************** 
 * Cltandfle *
 ******************/

import { core, data, sound, util, visual, hardware } from './lib/psychojs-2024.2.4.js';
const { PsychoJS } = core;
const { TrialHandler, MultiStairHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'CLTandFLE';  // from the Builder filename that created this script
let expInfo = {
    'participant': '',
    'group': '',
};

// Start code blocks for 'Before Experiment'
document.addEventListener('contextmenu',event => event.preventDefault());
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([1.0, 1.0, 1.0]),
  units: 'height',
  waitBlanking: true,
  backgroundImage: '',
  backgroundFit: 'none',
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); },flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(AlfaRoutineBegin());
flowScheduler.add(AlfaRoutineEachFrame());
flowScheduler.add(AlfaRoutineEnd());
flowScheduler.add(ITIRoutineBegin());
flowScheduler.add(ITIRoutineEachFrame());
flowScheduler.add(ITIRoutineEnd());
flowScheduler.add(B_consensoinformatoRoutineBegin());
flowScheduler.add(B_consensoinformatoRoutineEachFrame());
flowScheduler.add(B_consensoinformatoRoutineEnd());
const exp_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(exp_loopLoopBegin(exp_loopLoopScheduler));
flowScheduler.add(exp_loopLoopScheduler);
flowScheduler.add(exp_loopLoopEnd);























































flowScheduler.add(quitPsychoJS, 'Thank you for your patience.', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, 'Thank you for your patience.', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    // libraries:
    {'surveyLibrary': true},
    // resources:
    {'name': 'resources/ufficio.PNG', 'path': 'resources/ufficio.PNG'},
    {'name': 'resources/schermo.PNG', 'path': 'resources/schermo.PNG'},
    {'name': 'resources/intensity.PNG', 'path': 'resources/intensity.PNG'},
    {'name': 'resources/valence.PNG', 'path': 'resources/valence.PNG'},
    {'name': 'MedITA.json', 'path': 'MedITA.json'},
    {'name': 'MedENG.json', 'path': 'MedENG.json'},
    {'name': 'AzITA.json', 'path': 'AzITA.json'},
    {'name': 'AzENG.json', 'path': 'AzENG.json'},
    {'name': 'FlITA.json', 'path': 'FlITA.json'},
    {'name': 'FlENG.json', 'path': 'FlENG.json'},
    {'name': 'DemoE.json', 'path': 'DemoE.json'},
    {'name': 'YoE.json', 'path': 'YoE.json'},
    {'name': 'demoI.json', 'path': 'demoI.json'},
    {'name': 'YoI.json', 'path': 'YoI.json'},
    {'name': 'MEDPOS.xlsx', 'path': 'MEDPOS.xlsx'},
    {'name': 'ELEPOS.xlsx', 'path': 'ELEPOS.xlsx'},
    {'name': 'YELLPOS.xlsx', 'path': 'YELLPOS.xlsx'},
    {'name': 'resources/intensity.PNG', 'path': 'resources/intensity.PNG'},
    {'name': 'resources/valence.PNG', 'path': 'resources/valence.PNG'},
    {'name': 'resources/schermo.PNG', 'path': 'resources/schermo.PNG'},
    {'name': 'resources/ufficio.PNG', 'path': 'resources/ufficio.PNG'},
    {'name': 'YELLENGXL.xlsx', 'path': 'YELLENGXL.xlsx'},
    {'name': 'YELLITAXL.xlsx', 'path': 'YELLITAXL.xlsx'},
    {'name': 'ELETTRENGXL.xlsx', 'path': 'ELETTRENGXL.xlsx'},
    {'name': 'ELETTRITAXL.xlsx', 'path': 'ELETTRITAXL.xlsx'},
    {'name': 'MEDICINEENGXL.xlsx', 'path': 'MEDICINEENGXL.xlsx'},
    {'name': 'MEDICINEITAXL.xlsx', 'path': 'MEDICINEITAXL.xlsx'},
    {'name': 'YoI.json', 'path': 'YoI.json'},
    {'name': 'YoE.json', 'path': 'YoE.json'},
    {'name': 'demoI.json', 'path': 'demoI.json'},
    {'name': 'DemoE.json', 'path': 'DemoE.json'},
    {'name': 'FlENG.json', 'path': 'FlENG.json'},
    {'name': 'AzITA.json', 'path': 'AzITA.json'},
    {'name': 'AzENG.json', 'path': 'AzENG.json'},
    {'name': 'MedENG.json', 'path': 'MedENG.json'},
    {'name': 'FlITA.json', 'path': 'FlITA.json'},
    {'name': 'MedITA.json', 'path': 'MedITA.json'},
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2024.2.4';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls('https://app.prolific.com/submissions/complete?cc=C1B6W66A', '');


  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);
  psychoJS.experiment.field_separator = '\t';


  return Scheduler.Event.NEXT;
}


var AlfaClock;
var _pj;
var group;
var var_colore;
var var_testo;
var estita;
var esteng;
var clicka;
var dxcl;
var sxcl;
var survey1;
var survey2;
var survey3;
var survey4;
var survey5;
var survey6;
var conditionFile;
var alfa_linea;
var alfa_testo2;
var alfa_testo1;
var alfa_image2;
var alfa_image1;
var alfa_mask;
var alfa_clicca;
var alfa_mouse;
var ITIClock;
var ITI_fig;
var B_consensoinformatoClock;
var consensotitolo;
var okconsenso;
var noconsenso;
var avanticons;
var indietrocons;
var cons_tit;
var cons_indietro;
var cons_avanti;
var cons_avvio;
var cons_noavvio;
var cons_avviotext;
var cons_avviotext_3;
var cons_text;
var cons_nr_pag;
var cons_nr_pag_2;
var cons_nr_pag_3;
var cons_av_text;
var cons_in_text;
var cons_mouse;
var A_benvenutoClock;
var ben_testo1;
var ben_testo2;
var ben_testo_1;
var ben_testo_2;
var ben_qdr_2;
var ben_qdr_1;
var ben_qdrtno_1;
var ben_qdrtno_2;
var ben_qdrtno_3;
var ben_qdrtno_4;
var ben_mouse;
var ben_linea_sx;
var ben_linea_dx;
var B2_istruzioniClock;
var titoloistruzioni;
var tastoavanti;
var tastoindietro;
var tastocontinua;
var cons_tit_2;
var cons_indietro_2;
var cons_avanti_2;
var cons_avvio_2;
var cons_avviotext_2;
var cons_text_2;
var cons_nr_pag_4;
var cons_nr_pag_5;
var cons_nr_pag_6;
var cons_av_text_2;
var cons_in_text_2;
var cons_mouse_2;
var SAMevaluationClock;
var coin_flip;
var dom_sam;
var istr_saa;
var conf_sam;
var P1;
var P2;
var P3;
var P4;
var istr_sam;
var intensity;
var valence;
var cercvalence;
var cerchvalence2;
var Rett_slider_valence;
var titoloSAM;
var istr_SAM;
var istr_sam2;
var rettsliderintensity;
var cercintensity;
var cercintensity2;
var sliderintensity;
var rettoksam;
var slidervalence;
var ok_3;
var mouse_sam;
var LoadingClock;
var text22;
var loadreload;
var C_associative_taskClock;
var tempo_tasktot;
var tastosi;
var tastono;
var ate;
var linea;
var cerchio_2;
var cerchio;
var ass_r1_3;
var ass_r1_4;
var ass_r1_2;
var ass_r1;
var ass_psi;
var ass_pno;
var ass_primo_2;
var ass_primo;
var ass_secondo;
var ass_si;
var ass_no;
var ass_terzo_2;
var ass_terzo;
var maskuno;
var mouse;
var loadingquestionClock;
var loadreload2;
var testload;
var VD_dualClock;
var contino;
var VDquestion;
var VDmainSI;
var VDmainNO;
var domanda;
var vd_dual_titolo;
var ass_vdsi;
var ass_vdno;
var VD_si;
var VD_no;
var mouse_vddual;
var isttr_vdx;
var D_VDClock;
var taconferma;
var tasp;
var tasp2;
var taconf;
var tadom;
var tadomanda;
var cerch1;
var rett;
var cerch1_2;
var vd;
var feedback;
var rettok;
var ok;
var istr_vd;
var istr_vd_3;
var istr_vd_2;
var vd_titolo;
var mouse_vd;
var PreviousClock;
var taconferma1;
var tasp1;
var tasp21;
var taconf1;
var tadom1;
var tadomanda1;
var cerch1_3;
var rett_2;
var cerch1_4;
var previous;
var feedback_3;
var rettok_2;
var ok_4;
var istr_vd_4;
var istr_vd_5;
var istr_vd_6;
var vd_titolo_2;
var mouse_vd_2;
var D_VD2Clock;
var taconferma16;
var tasp16;
var tasp216;
var taconf16;
var tadom16;
var tadomanda16;
var cerch1_5;
var rett_3;
var cerch1_6;
var previous_2;
var feedback_4;
var rettok_3;
var ok_5;
var istr_vd_7;
var istr_vd_8;
var istr_vd_9;
var vd_titolo_3;
var mouse_vd_3;
var D_VD3Clock;
var taconferma167;
var tasp167;
var tasp2167;
var taconf167;
var tadom167;
var tadomanda167;
var cerch1_7;
var rett_4;
var cerch1_8;
var previous_3;
var feedback_5;
var rettok_4;
var ok_6;
var istr_vd_10;
var istr_vd_11;
var istr_vd_12;
var vd_titolo_4;
var mouse_vd_4;
var Ant_lastquestionClock;
var textino;
var finalT;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "Alfa"
  AlfaClock = new util.Clock();
  // Run 'Begin Experiment' code from alfa_code
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  group = Number.parseInt(expInfo["group"]);
  var_colore = [(- 1), (- 1), (- 1)];
  var_testo = "Arial";
  if (_pj.in_es6(group, [1, 3, 5])) {
      estita = 1;
      esteng = 0;
      clicka = "Clicca QUI per cominciare";
      dxcl = "Cerca di operare in un ambiente che sia: \n(1) al chiuso \n(2) sufficientemente illuminato \n(3) senza fonti di luce dirette sullo schermo";
      sxcl = "Assicurati che lo schermo su cui hai avviato \nl'esperimento sia in modalit\u00e0 schermo intero.\nMantieni questa modalit\u00e0 per tutta \nla durata dell'esperimento.";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          estita = 0;
          esteng = 1;
          clicka = "Click HERE to begin";
          dxcl = "Try to perform the task in an environment that is: \n(1) indoors \n(2) sufficiently illuminated \n(3) without direct light sources on the screen";
          sxcl = "Make sure the screen where you started the \nexperiment is set to fullscreen mode. \nKeep this mode throughout \n the duration of the experiment.";
      } else {
          throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
      }
  }
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      survey1 = 1;
      survey2 = 0;
      survey3 = 0;
      survey4 = 0;
      survey5 = 0;
      survey6 = 0;
      conditionFile = "MEDICINEITAXL.xlsx";
  } else {
      if ((Number.parseInt(expInfo["group"]) === 2)) {
          survey1 = 0;
          survey2 = 1;
          survey3 = 0;
          survey4 = 0;
          survey5 = 0;
          survey6 = 0;
          conditionFile = "MEDPOS.xlsx";
      } else {
          if ((Number.parseInt(expInfo["group"]) === 3)) {
              survey1 = 0;
              survey2 = 0;
              survey3 = 1;
              survey4 = 0;
              survey5 = 0;
              survey6 = 0;
              conditionFile = "ELETTRITAXL.xlsx";
          } else {
              if ((Number.parseInt(expInfo["group"]) === 4)) {
                  survey1 = 0;
                  survey2 = 0;
                  survey3 = 0;
                  survey4 = 1;
                  survey5 = 0;
                  survey6 = 0;
                  conditionFile = "ELEPOS.xlsx";
              } else {
                  if ((Number.parseInt(expInfo["group"]) === 5)) {
                      survey1 = 0;
                      survey2 = 0;
                      survey3 = 0;
                      survey4 = 0;
                      survey5 = 1;
                      survey6 = 0;
                      conditionFile = "YELLITAXL.xlsx";
                  } else {
                      if ((Number.parseInt(expInfo["group"]) === 6)) {
                          survey1 = 0;
                          survey2 = 0;
                          survey3 = 0;
                          survey4 = 0;
                          survey5 = 0;
                          survey6 = 1;
                          conditionFile = "YELLPOS.xlsx";
                      }
                  }
              }
          }
      }
  }
  
  alfa_linea = new visual.Rect ({
    win: psychoJS.window, name: 'alfa_linea', 
    width: [0.005, 0.8][0], height: [0.005, 0.8][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -1, 
    interpolate: true, 
  });
  
  alfa_testo2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'alfa_testo2',
    text: dxcl,
    font: 'Arial',
    units: undefined, 
    pos: [0.4, 0.2], draggable: false, height: 0.035,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  alfa_testo1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'alfa_testo1',
    text: sxcl,
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.4), 0.2], draggable: false, height: 0.035,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: -3.0 
  });
  
  alfa_image2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'alfa_image2', units : undefined, 
    image : 'resources/ufficio.PNG', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : [0.4, (- 0.2)], 
    draggable: false,
    size : [0.35, 0.35],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -4.0 
  });
  alfa_image1 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'alfa_image1', units : undefined, 
    image : 'resources/schermo.PNG', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : [(- 0.4), (- 0.2)], 
    draggable: false,
    size : [0.45, 0.45],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -5.0 
  });
  alfa_mask = new visual.Rect ({
    win: psychoJS.window, name: 'alfa_mask', 
    width: [0.3, 0.2][0], height: [0.3, 0.2][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -6, 
    interpolate: true, 
  });
  
  alfa_clicca = new visual.TextStim({
    win: psychoJS.window,
    name: 'alfa_clicca',
    text: clicka,
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -7.0 
  });
  
  alfa_mouse = new core.Mouse({
    win: psychoJS.window,
  });
  alfa_mouse.mouseClock = new util.Clock();
  // Initialize components for Routine "ITI"
  ITIClock = new util.Clock();
  ITI_fig = new visual.ShapeStim ({
    win: psychoJS.window, name: 'ITI_fig', 
    vertices: [[-[0, 0][0]/2.0, -[0, 0][1]/2.0], [+[0, 0][0]/2.0, -[0, 0][1]/2.0], [0, [0, 0][1]/2.0]],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: 0, 
    interpolate: true, 
  });
  
  // Initialize components for Routine "B_consensoinformato"
  B_consensoinformatoClock = new util.Clock();
  // Run 'Begin Experiment' code from cons_code
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  if (_pj.in_es6(group, [1, 3, 5])) {
      consensotitolo = "Consenso informato";
      okconsenso = "Accetta";
      noconsenso = "Rifiuta";
      avanticons = "Avanti";
      indietrocons = "Indietro";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          consensotitolo = "Informed Consent";
          okconsenso = "Accept";
          noconsenso = "Reject";
          avanticons = "Next";
          indietrocons = "Back";
      }
  }
  
  cons_tit = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_tit',
    text: consensotitolo,
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.39], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  cons_indietro = new visual.Rect ({
    win: psychoJS.window, name: 'cons_indietro', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [(- 0.3), 0.25], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 2.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -2, 
    interpolate: true, 
  });
  
  cons_avanti = new visual.Rect ({
    win: psychoJS.window, name: 'cons_avanti', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0.3, 0.25], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 2.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -3, 
    interpolate: true, 
  });
  
  cons_avvio = new visual.Rect ({
    win: psychoJS.window, name: 'cons_avvio', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0.2, (- 0.4)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 2.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -4, 
    interpolate: true, 
  });
  
  cons_noavvio = new visual.Rect ({
    win: psychoJS.window, name: 'cons_noavvio', 
    width: [(- 0.2), 0.1][0], height: [(- 0.2), 0.1][1],
    ori: 0.0, 
    pos: [(- 0.2), (- 0.4)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 2.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -5, 
    interpolate: true, 
  });
  
  cons_avviotext = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_avviotext',
    text: okconsenso,
    font: 'Arial',
    units: undefined, 
    pos: [0.2, (- 0.4)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), 0.0039, (- 1.0)]),  opacity: 1.0,
    depth: -6.0 
  });
  
  cons_avviotext_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_avviotext_3',
    text: noconsenso,
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.2), (- 0.4)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([0.0902, (- 1.0), (- 1.0)]),  opacity: 1.0,
    depth: -7.0 
  });
  
  cons_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_text',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.1)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -8.0 
  });
  
  cons_nr_pag = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_nr_pag',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.02), 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -9.0 
  });
  
  cons_nr_pag_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_nr_pag_2',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -10.0 
  });
  
  cons_nr_pag_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_nr_pag_3',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0.02, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -11.0 
  });
  
  cons_av_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_av_text',
    text: avanticons,
    font: 'Arial',
    units: undefined, 
    pos: [0.3, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: 1.0,
    depth: -12.0 
  });
  
  cons_in_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_in_text',
    text: indietrocons,
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.3), 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: 1.0,
    depth: -13.0 
  });
  
  cons_mouse = new core.Mouse({
    win: psychoJS.window,
  });
  cons_mouse.mouseClock = new util.Clock();
  // Initialize components for Routine "A_benvenuto"
  A_benvenutoClock = new util.Clock();
  // Run 'Begin Experiment' code from ben_code
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  if (_pj.in_es6(group, [1, 3, 5])) {
      ben_testo1 = "Benvenuta/o all'esperimento!";
      ben_testo2 = "Clicca per iniziare";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          ben_testo1 = "Welcome to the experiment!";
          ben_testo2 = "Click to start";
      } else {
          throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
      }
  }
  
  ben_testo_1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ben_testo_1',
    text: ben_testo1,
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.1], draggable: false, height: 0.07,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: 1.0,
    depth: -1.0 
  });
  
  ben_testo_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ben_testo_2',
    text: ben_testo2,
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.1)], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -2.0 
  });
  
  ben_qdr_2 = new visual.Rect ({
    win: psychoJS.window, name: 'ben_qdr_2', 
    width: [0.025, 0.025][0], height: [0.025, 0.025][1],
    ori: 45.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('black'), 
    fillColor: undefined, 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -3, 
    interpolate: true, 
  });
  
  ben_qdr_1 = new visual.Rect ({
    win: psychoJS.window, name: 'ben_qdr_1', 
    width: [0.015, 0.015][0], height: [0.015, 0.015][1],
    ori: 45.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 2.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -4, 
    interpolate: true, 
  });
  
  ben_qdrtno_1 = new visual.Rect ({
    win: psychoJS.window, name: 'ben_qdrtno_1', 
    width: [0.01, 0.01][0], height: [0.01, 0.01][1],
    ori: 45.0, 
    pos: [(- 0.03), 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -5, 
    interpolate: true, 
  });
  
  ben_qdrtno_2 = new visual.Rect ({
    win: psychoJS.window, name: 'ben_qdrtno_2', 
    width: [0.01, 0.01][0], height: [0.01, 0.01][1],
    ori: 45.0, 
    pos: [0.03, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -6, 
    interpolate: true, 
  });
  
  ben_qdrtno_3 = new visual.Rect ({
    win: psychoJS.window, name: 'ben_qdrtno_3', 
    width: [0.01, 0.01][0], height: [0.01, 0.01][1],
    ori: 45.0, 
    pos: [0.05, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -7, 
    interpolate: true, 
  });
  
  ben_qdrtno_4 = new visual.Rect ({
    win: psychoJS.window, name: 'ben_qdrtno_4', 
    width: [0.01, 0.01][0], height: [0.01, 0.01][1],
    ori: 45.0, 
    pos: [(- 0.05), 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -8, 
    interpolate: true, 
  });
  
  ben_mouse = new core.Mouse({
    win: psychoJS.window,
  });
  ben_mouse.mouseClock = new util.Clock();
  ben_linea_sx = new visual.Rect ({
    win: psychoJS.window, name: 'ben_linea_sx', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, 
    pos: [(- 0.35), 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -10, 
    interpolate: true, 
  });
  
  ben_linea_dx = new visual.Rect ({
    win: psychoJS.window, name: 'ben_linea_dx', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, 
    pos: [0.35, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -11, 
    interpolate: true, 
  });
  
  // Initialize components for Routine "B2_istruzioni"
  B2_istruzioniClock = new util.Clock();
  // Run 'Begin Experiment' code from cons_code_2
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  if (_pj.in_es6(group, [1, 3, 5])) {
      titoloistruzioni = "Istruzioni";
      tastoavanti = "Avanti";
      tastoindietro = "Indietro";
      tastocontinua = "Continua";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          titoloistruzioni = "Instructions";
          tastoavanti = "Next";
          tastoindietro = "Back";
          tastocontinua = "Continue";
      } else {
          throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
      }
  }
  
  cons_tit_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_tit_2',
    text: titoloistruzioni,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.39], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -1.0 
  });
  
  cons_indietro_2 = new visual.Rect ({
    win: psychoJS.window, name: 'cons_indietro_2', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [(- 0.3), 0.25], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 2.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -2, 
    interpolate: true, 
  });
  
  cons_avanti_2 = new visual.Rect ({
    win: psychoJS.window, name: 'cons_avanti_2', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0.3, 0.25], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 2.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -3, 
    interpolate: true, 
  });
  
  cons_avvio_2 = new visual.Rect ({
    win: psychoJS.window, name: 'cons_avvio_2', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0, (- 0.4)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 2.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -4, 
    interpolate: true, 
  });
  
  cons_avviotext_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_avviotext_2',
    text: tastocontinua,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.4)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -5.0 
  });
  
  cons_text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_text_2',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.1)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -6.0 
  });
  
  cons_nr_pag_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_nr_pag_4',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [(- 0.02), 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -7.0 
  });
  
  cons_nr_pag_5 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_nr_pag_5',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -8.0 
  });
  
  cons_nr_pag_6 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_nr_pag_6',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0.02, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -9.0 
  });
  
  cons_av_text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_av_text_2',
    text: tastoavanti,
    font: var_testo,
    units: undefined, 
    pos: [0.3, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -10.0 
  });
  
  cons_in_text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'cons_in_text_2',
    text: tastoindietro,
    font: var_testo,
    units: undefined, 
    pos: [(- 0.3), 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -11.0 
  });
  
  cons_mouse_2 = new core.Mouse({
    win: psychoJS.window,
  });
  cons_mouse_2.mouseClock = new util.Clock();
  // Initialize components for Routine "SAMevaluation"
  SAMevaluationClock = new util.Clock();
  // Run 'Begin Experiment' code from code_6
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  coin_flip = Math.random();
  if (_pj.in_es6(group, [1, 3, 5])) {
      dom_sam = "Domanda";
      istr_saa = "Come ti sei sentita/o nel leggere questa storia che ti \u00e8 stata presentata?";
      conf_sam = "Conferma";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          dom_sam = "Question";
          istr_saa = "How did you feel while reading this story that was presented to you?";
          conf_sam = "Confirm";
      } else {
          throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
      }
  }
  P1 = 0.2;
  P2 = 0;
  P3 = 0.15;
  P4 = 0.05;
  if ((coin_flip < 0.5)) {
      P1 = [0, 0.2];
      P2 = [0, 0];
      P3 = [0, 0.14];
      P4 = [0, (- 0.06)];
      if (_pj.in_es6(group, [1, 3, 5])) {
          istr_sam = (((("Utilizza gli slider qui sopra per fornire una risposta." + " Il primo slider chiede quale emozione stai provando (da triste a felice).") + " Il secondo slider chiede quanto ti senti attivata/o (da calma/o ad attivata/o).") + " Quando avrai selezionato una risposta per entrambi gli") + " slider apparir\u00e0 il tasto Conferma per proseguire.");
      } else {
          istr_sam = ((("Use the sliders above to provide an answer." + " The first slider asks which emotion you are feeling (from sad to happy).") + " The second slider asks how activated you feel (from calm to activated).") + " Once you have selected an answer for both sliders, the Confirm button will appear to continue.");
      }
  } else {
      if ((coin_flip > 0.5)) {
          P1 = [0, 0];
          P2 = [0, 0.2];
          P3 = [0, (- 0.06)];
          P4 = [0, 0.14];
          if (_pj.in_es6(group, [1, 3, 5])) {
              istr_sam = (((("Utilizza gli slider qui sopra per fornire una risposta." + " Il primo slider chiede quanto ti senti attivata/o (da calma/o ad attivata/o).") + " Il secondo slider chiede quale emozione stai provando (da triste a felice).") + " Quando avrai selezionato una risposta per entrambi gli") + " slider apparir\u00e0 il tasto Conferma per proseguire.");
          } else {
              istr_sam = ((("Use the sliders above to provide an answer." + " The first slider asks how activated you feel (from calm to activated).") + " The second slider asks which emotion you are feeling (from sad to happy).") + " Once you have selected an answer for both sliders, the Confirm button will appear to continue.");
          }
      }
  }
  
  intensity = new visual.ImageStim({
    win : psychoJS.window,
    name : 'intensity', units : undefined, 
    image : 'resources/intensity.PNG', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : P4, 
    draggable: false,
    size : [1, 0.3],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  valence = new visual.ImageStim({
    win : psychoJS.window,
    name : 'valence', units : undefined, 
    image : 'resources/valence.PNG', mask : undefined,
    anchor : 'center',
    ori : 0.0, 
    pos : P3, 
    draggable: false,
    size : [1, 0.3],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  cercvalence = new visual.Polygon({
    win: psychoJS.window, name: 'cercvalence', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [(- 0.4), 0.2], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -3, 
    interpolate: true, 
  });
  
  cerchvalence2 = new visual.Polygon({
    win: psychoJS.window, name: 'cerchvalence2', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [0.4, 0.2], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -4, 
    interpolate: true, 
  });
  
  Rett_slider_valence = new visual.Rect ({
    win: psychoJS.window, name: 'Rett_slider_valence', 
    width: [0.8, 0.07][0], height: [0.8, 0.07][1],
    ori: 0.0, 
    pos: [0, 0.2], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -5, 
    interpolate: true, 
  });
  
  titoloSAM = new visual.TextStim({
    win: psychoJS.window,
    name: 'titoloSAM',
    text: dom_sam,
    font: 'Arial',
    units: undefined, 
    pos: [0, 0.42], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: -6.0 
  });
  
  istr_SAM = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_SAM',
    text: istr_saa,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.3], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -7.0 
  });
  
  istr_sam2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_sam2',
    text: istr_sam,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.35)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -8.0 
  });
  
  rettsliderintensity = new visual.Rect ({
    win: psychoJS.window, name: 'rettsliderintensity', 
    width: [0.8, 0.07][0], height: [0.8, 0.07][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -9, 
    interpolate: true, 
  });
  
  cercintensity = new visual.Polygon({
    win: psychoJS.window, name: 'cercintensity', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [(- 0.4), 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -10, 
    interpolate: true, 
  });
  
  cercintensity2 = new visual.Polygon({
    win: psychoJS.window, name: 'cercintensity2', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [0.4, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -11, 
    interpolate: true, 
  });
  
  sliderintensity = new visual.Slider({
    win: psychoJS.window, name: 'sliderintensity',
    startValue: 0.5,
    size: [0.8, 0.05], pos: P2, ori: 0.0, units: psychoJS.window.units,
    labels: undefined, fontSize: 0.05, ticks: [0, 0.5, 1],
    granularity: 0.0, style: ["RATING"],
    color: new util.Color('LightGray'), markerColor: new util.Color('white'), lineColor: new util.Color([0.5216, 0.5216, 0.5216]), 
    opacity: undefined, fontFamily: 'Open Sans', bold: true, italic: false, depth: -12, 
    flip: false,
  });
  
  rettoksam = new visual.Rect ({
    win: psychoJS.window, name: 'rettoksam', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0, (- 0.21)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -13, 
    interpolate: true, 
  });
  
  slidervalence = new visual.Slider({
    win: psychoJS.window, name: 'slidervalence',
    startValue: 0.5,
    size: [0.8, 0.05], pos: P1, ori: 0.0, units: psychoJS.window.units,
    labels: undefined, fontSize: 0.05, ticks: [0, 0.5, 1],
    granularity: 0.0, style: ["RATING"],
    color: new util.Color('LightGray'), markerColor: new util.Color('white'), lineColor: new util.Color([0.5216, 0.5216, 0.5216]), 
    opacity: undefined, fontFamily: 'Open Sans', bold: true, italic: false, depth: -14, 
    flip: false,
  });
  
  ok_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ok_3',
    text: conf_sam,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.21)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -15.0 
  });
  
  mouse_sam = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_sam.mouseClock = new util.Clock();
  // Initialize components for Routine "Loading"
  LoadingClock = new util.Clock();
  text22 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text22',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: 0.0 
  });
  
  // Run 'Begin Experiment' code from code_7
  loadreload = "L";
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      loadreload = "Caricamento delle cartelle cliniche dei pazienti...";
  }
  if ((Number.parseInt(expInfo["group"]) === 2)) {
      loadreload = "Loading the patients' medical records...";
  }
  if ((Number.parseInt(expInfo["group"]) === 3)) {
      loadreload = "Caricamento dei registri delle aziende...";
  }
  if ((Number.parseInt(expInfo["group"]) === 4)) {
      loadreload = "Loading the facilities' records...";
  }
  if ((Number.parseInt(expInfo["group"]) === 5)) {
      loadreload = "Caricamento dei registri delle osservazioni effettuate sul pianeta Yellowland...";
  }
  if ((Number.parseInt(expInfo["group"]) === 6)) {
      loadreload = "Loading observation records from the planet Yellowland...";
  }
  
  // Initialize components for Routine "C_associative_task"
  C_associative_taskClock = new util.Clock();
  // Run 'Begin Experiment' code from code_ass
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  tempo_tasktot = 0;
  if (_pj.in_es6(group, [1, 3, 5])) {
      tastosi = "S\u00ec";
      tastono = "No";
  } else {
      tastosi = "Yes";
      tastono = "No";
  }
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      ate = "Pensi che il paziente superer\u00e0 la crisi?";
  }
  if ((Number.parseInt(expInfo["group"]) === 2)) {
      ate = "Do you think the patient will overcome the crisis?";
  }
  if ((Number.parseInt(expInfo["group"]) === 3)) {
      ate = "Pensi che il Laminatorix si fermer\u00e0?";
  }
  if ((Number.parseInt(expInfo["group"]) === 4)) {
      ate = "Do you think the Laminatorix will stop?";
  }
  if ((Number.parseInt(expInfo["group"]) === 5)) {
      ate = "Pensi che lo Yellowpop cambier\u00e0 colore?";
  }
  if ((Number.parseInt(expInfo["group"]) === 6)) {
      ate = "Do you think the Yellowpop will change color?";
  }
  
  linea = new visual.ShapeStim ({
    win: psychoJS.window, name: 'linea', 
    vertices: [[-[1.1, 0.52][0]/2.0, 0], [+[1.1, 0.52][0]/2.0, 0]],
    ori: 0.0, 
    pos: [0, 0.26], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 5.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -1, 
    interpolate: true, 
  });
  
  cerchio_2 = new visual.Polygon({
    win: psychoJS.window, name: 'cerchio_2', 
    edges: 100, size:[0.02, 0.02],
    ori: 0.0, 
    pos: [0.55, 0.26], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -2, 
    interpolate: true, 
  });
  
  cerchio = new visual.Polygon({
    win: psychoJS.window, name: 'cerchio', 
    edges: 100, size:[0.02, 0.02],
    ori: 0.0, 
    pos: [(- 0.55), 0.26], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -3, 
    interpolate: true, 
  });
  
  ass_r1_3 = new visual.ShapeStim ({
    win: psychoJS.window, name: 'ass_r1_3', 
    vertices: [[-[0.01, 0.01][0]/2.0, -[0.01, 0.01][1]/2.0], [+[0.01, 0.01][0]/2.0, -[0.01, 0.01][1]/2.0], [0, [0.01, 0.01][1]/2.0]],
    ori: 0.0, 
    pos: [0, (- 0.45)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([1.0, 1.0, 1.0]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -4, 
    interpolate: true, 
  });
  
  ass_r1_4 = new visual.Rect ({
    win: psychoJS.window, name: 'ass_r1_4', 
    width: [1, 0.15][0], height: [1, 0.15][1],
    ori: 0.0, 
    pos: [0, (- 0.175)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -5, 
    interpolate: true, 
  });
  
  ass_r1_2 = new visual.Rect ({
    win: psychoJS.window, name: 'ass_r1_2', 
    width: [1, 0.2][0], height: [1, 0.2][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -6, 
    interpolate: true, 
  });
  
  ass_r1 = new visual.Rect ({
    win: psychoJS.window, name: 'ass_r1', 
    width: [1, 0.15][0], height: [1, 0.15][1],
    ori: 0.0, 
    pos: [0, 0.175], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -7, 
    interpolate: true, 
  });
  
  ass_psi = new visual.Rect ({
    win: psychoJS.window, name: 'ass_psi', 
    width: [0.15, 0.06][0], height: [0.15, 0.06][1],
    ori: 0.0, 
    pos: [(- 0.2), (- 0.04)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -8, 
    interpolate: true, 
  });
  
  ass_pno = new visual.Rect ({
    win: psychoJS.window, name: 'ass_pno', 
    width: [0.15, 0.06][0], height: [0.15, 0.06][1],
    ori: 0.0, 
    pos: [0.2, (- 0.04)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -9, 
    interpolate: true, 
  });
  
  ass_primo_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ass_primo_2',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, 0.155], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -10.0 
  });
  
  ass_primo = new visual.TextStim({
    win: psychoJS.window,
    name: 'ass_primo',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, 0.18], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -11.0 
  });
  
  ass_secondo = new visual.TextStim({
    win: psychoJS.window,
    name: 'ass_secondo',
    text: ate,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.04], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -12.0 
  });
  
  ass_si = new visual.TextStim({
    win: psychoJS.window,
    name: 'ass_si',
    text: tastosi,
    font: var_testo,
    units: undefined, 
    pos: [(- 0.2), (- 0.04)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -13.0 
  });
  
  ass_no = new visual.TextStim({
    win: psychoJS.window,
    name: 'ass_no',
    text: tastono,
    font: var_testo,
    units: undefined, 
    pos: [0.2, (- 0.04)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -14.0 
  });
  
  ass_terzo_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ass_terzo_2',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.195)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: 1.0,
    depth: -15.0 
  });
  
  ass_terzo = new visual.TextStim({
    win: psychoJS.window,
    name: 'ass_terzo',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.17)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -16.0 
  });
  
  maskuno = new visual.Rect ({
    win: psychoJS.window, name: 'maskuno', 
    width: [1.06, 0.51][0], height: [1.06, 0.51][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 0.0, 
    lineColor: new util.Color('white'), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -17, 
    interpolate: true, 
  });
  
  mouse = new core.Mouse({
    win: psychoJS.window,
  });
  mouse.mouseClock = new util.Clock();
  // Initialize components for Routine "loadingquestion"
  loadingquestionClock = new util.Clock();
  // Run 'Begin Experiment' code from code_10
  loadreload2 = "L";
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      loadreload2 = "La fase di osservazione \u00e8 terminata, caricamento delle domande...";
  }
  if ((Number.parseInt(expInfo["group"]) === 2)) {
      loadreload2 = "The observation phase is over, loading questions...";
  }
  if ((Number.parseInt(expInfo["group"]) === 3)) {
      loadreload2 = "La fase di osservazione \u00e8 terminata, caricamento delle domande...";
  }
  if ((Number.parseInt(expInfo["group"]) === 4)) {
      loadreload2 = "The observation phase is over, loading questions...";
  }
  if ((Number.parseInt(expInfo["group"]) === 5)) {
      loadreload2 = "La fase di osservazione \u00e8 terminata, caricamento delle domande...";
  }
  if ((Number.parseInt(expInfo["group"]) === 6)) {
      loadreload2 = "The observation phase is over, loading questions...";
  }
  
  testload = new visual.TextStim({
    win: psychoJS.window,
    name: 'testload',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: -1.0 
  });
  
  // Initialize components for Routine "VD_dual"
  VD_dualClock = new util.Clock();
  // Run 'Begin Experiment' code from code_9
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  contino = 0;
  if (_pj.in_es6(group, [1, 3, 5])) {
      VDquestion = "Domanda";
      VDmainSI = "S\u00ec";
      VDmainNO = "No";
  }
  if (_pj.in_es6(group, [2, 4, 6])) {
      VDquestion = "Question";
      VDmainSI = "Yes";
      VDmainNO = "No";
  }
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      domanda = "Pensi che il Batatrim sia stato efficace nel curare i pazienti che hai visto?";
  }
  if ((Number.parseInt(expInfo["group"]) === 2)) {
      domanda = "Do you think Batatrim was effective in treating the patients you have seen?";
  }
  if ((Number.parseInt(expInfo["group"]) === 3)) {
      domanda = "Pensi che il sistema NZ-6 sia stato efficace nel fermare il Laminatorix nelle aziende che hai visto?";
  }
  if ((Number.parseInt(expInfo["group"]) === 4)) {
      domanda = "Do you think NZ-6 system was effective in stopping the Laminatorix in the facilities you have seen?";
  }
  if ((Number.parseInt(expInfo["group"]) === 5)) {
      domanda = "Pensi che il Fluffberry sia stato efficace nel cambiare il colore degli Yellowpop che hai visto?";
  }
  if ((Number.parseInt(expInfo["group"]) === 6)) {
      domanda = "Do you think Fluffberry was effective in changing the colors in the Yellowpops you have seen?";
  }
  
  vd_dual_titolo = new visual.TextStim({
    win: psychoJS.window,
    name: 'vd_dual_titolo',
    text: VDquestion,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.42], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -1.0 
  });
  
  ass_vdsi = new visual.Rect ({
    win: psychoJS.window, name: 'ass_vdsi', 
    width: [0.18, 0.09][0], height: [0.18, 0.09][1],
    ori: 0.0, 
    pos: [(- 0.2), 0.1], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -2, 
    interpolate: true, 
  });
  
  ass_vdno = new visual.Rect ({
    win: psychoJS.window, name: 'ass_vdno', 
    width: [0.18, 0.09][0], height: [0.18, 0.09][1],
    ori: 0.0, 
    pos: [0.2, 0.1], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: 1.0, 
    depth: -3, 
    interpolate: true, 
  });
  
  VD_si = new visual.TextStim({
    win: psychoJS.window,
    name: 'VD_si',
    text: VDmainSI,
    font: var_testo,
    units: undefined, 
    pos: [(- 0.2), 0.1], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -4.0 
  });
  
  VD_no = new visual.TextStim({
    win: psychoJS.window,
    name: 'VD_no',
    text: VDmainNO,
    font: var_testo,
    units: undefined, 
    pos: [0.2, 0.1], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: 1.0,
    depth: -5.0 
  });
  
  mouse_vddual = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_vddual.mouseClock = new util.Clock();
  isttr_vdx = new visual.TextStim({
    win: psychoJS.window,
    name: 'isttr_vdx',
    text: domanda,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.2], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -7.0 
  });
  
  // Initialize components for Routine "D_VD"
  D_VDClock = new util.Clock();
  // Run 'Begin Experiment' code from code_vd
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  if (_pj.in_es6(group, [1, 3, 5])) {
      taconferma = "Conferma";
      tasp = "(la scala va da 1 a 10: con 1 che significa pochissimo, e 10 che significa decisamente efficace)";
      tasp2 = "Clicca sulla barra sopra, e vedrai apparire uno slider. Puoi trascinare questo slider su qualsiasi punto della scala. Una volta che sei soddisfatta/o della tua risposta, clicca il pulsante Conferma.";
      taconf = "Conferma";
      tadom = "Domanda";
  }
  if (_pj.in_es6(group, [2, 4, 6])) {
      taconferma = "Confirm";
      tasp = "(the scale ranges from 1 to 10: with 1 meaning very little, and 10 meaning definitely effective)";
      tasp2 = "Click on the bar above, and you will see a slider appear. You can drag this slider to any point on the scale. Once you are satisfied with your answer, click the Confirm button.";
      taconf = "Confirm";
      tadom = "Question";
  }
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      tadomanda = "Quanto pensi che il Batatrim sia stato efficace nel curare i pazienti che hai visto?";
  }
  if ((Number.parseInt(expInfo["group"]) === 2)) {
      tadomanda = "How effective do you think Batatrim was in treating the patients you have seen?";
  }
  if ((Number.parseInt(expInfo["group"]) === 3)) {
      tadomanda = "Quanto pensi che il sistema NZ-6 sia stato efficace nel fermare il Laminatorix nelle aziende che hai visto?";
  }
  if ((Number.parseInt(expInfo["group"]) === 4)) {
      tadomanda = "How effective do you think the NZ-6 system was in stopping the Laminatorix in the facilities you have seen?";
  }
  if ((Number.parseInt(expInfo["group"]) === 5)) {
      tadomanda = "Quanto pensi che il Fluffberry sia stato efficace nel cambiare il colore degli Yellowpop che hai visto?";
  }
  if ((Number.parseInt(expInfo["group"]) === 6)) {
      tadomanda = "How effective do you think Fluffberry was in changing the colors of the Yellowpops you have seen?";
  }
  
  cerch1 = new visual.Polygon({
    win: psychoJS.window, name: 'cerch1', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [(- 0.4), 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -1, 
    interpolate: true, 
  });
  
  rett = new visual.Rect ({
    win: psychoJS.window, name: 'rett', 
    width: [0.8, 0.07][0], height: [0.8, 0.07][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -2, 
    interpolate: true, 
  });
  
  cerch1_2 = new visual.Polygon({
    win: psychoJS.window, name: 'cerch1_2', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [0.4, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -3, 
    interpolate: true, 
  });
  
  vd = new visual.Slider({
    win: psychoJS.window, name: 'vd',
    startValue: undefined,
    size: [0.8, 0.05], pos: [0, 0], ori: 0.0, units: psychoJS.window.units,
    labels: [1, 10], fontSize: 0.03, ticks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color(var_colore), markerColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), lineColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: -4, 
    flip: false,
  });
  
  feedback = new visual.TextStim({
    win: psychoJS.window,
    name: 'feedback',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.1)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -5.0 
  });
  
  rettok = new visual.Rect ({
    win: psychoJS.window, name: 'rettok', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0, (- 0.2)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -6, 
    interpolate: true, 
  });
  
  ok = new visual.TextStim({
    win: psychoJS.window,
    name: 'ok',
    text: taconferma,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.2)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -7.0 
  });
  
  istr_vd = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd',
    text: tadomanda,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.2], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -8.0 
  });
  
  istr_vd_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_3',
    text: tasp,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.14], draggable: false, height: 0.025,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -9.0 
  });
  
  istr_vd_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_2',
    text: tasp2,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.35)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -10.0 
  });
  
  vd_titolo = new visual.TextStim({
    win: psychoJS.window,
    name: 'vd_titolo',
    text: tadom,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.42], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -11.0 
  });
  
  mouse_vd = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_vd.mouseClock = new util.Clock();
  // Initialize components for Routine "Previous"
  PreviousClock = new util.Clock();
  // Run 'Begin Experiment' code from code_vd_3
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  if (_pj.in_es6(group, [1, 3, 5])) {
      taconferma1 = "Conferma";
      tasp1 = "(la scala va da 0 a 100: con 0 che significa decisamente non efficace, e 100 che significa decisamente efficace)";
      tasp21 = "Clicca sulla barra sopra, e vedrai apparire uno slider. Puoi trascinare questo slider su qualsiasi punto della scala. Una volta soddisfatta/o della tua risposta, clicca il pulsante Conferma.";
      taconf1 = "Conferma";
      tadom1 = "Domanda";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          taconferma1 = "Confirm";
          tasp1 = "(the scale ranges from 0 to 100: with 0 being definitely not effective, and 100 being definitely effective)";
          tasp21 = "Click on the bar above, and you will see a slider appear. You can drag this slider to any point on the scale. Once you are satisfied with your answer, click the Confirm button.";
          taconf1 = "Confirm";
          tadom1 = "Question";
      } else {
          throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
      }
  }
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      tadomanda1 = "Al di l\u00e0 del caso specifico del Batatrim, nella tua esperienza PERSONALE, quanto credi che i farmaci sono efficaci IN GENERALE nel curare le malattie?";
  }
  if ((Number.parseInt(expInfo["group"]) === 2)) {
      tadomanda1 = "Beyond the specific case of Batatrim, in your PERSONAL experience, how effective do you believe medications are IN GENERAL in curing diseases?";
  }
  if ((Number.parseInt(expInfo["group"]) === 3)) {
      tadomanda1 = "Al di l\u00e0 del caso specifico del sistema NZ-6, nella tua esperienza PERSONALE, quanto credi che le leve dei sistemi di emergenza sono efficaci IN GENERALE nel produrre un arresto del sistema?";
  }
  if ((Number.parseInt(expInfo["group"]) === 4)) {
      tadomanda1 = "Beyond the specific case of the NZ-6 system, in your PERSONAL experience, how effective do you believe emergency system levers are IN GENERAL in causing a system shutdown?";
  }
  if ((Number.parseInt(expInfo["group"]) === 5)) {
      tadomanda1 = "Al di l\u00e0 del caso specifico del Fluffberry, nella tua esperienza PERSONALE, quanto credi che i frutti sono efficaci IN GENERALE nel produrre un cambio di colore negli esseri viventi?";
  }
  if ((Number.parseInt(expInfo["group"]) === 6)) {
      tadomanda1 = "Beyond the specific case of the Fluffberry, in your PERSONAL experience, how effective do you believe fruits are IN GENERAL in causing a color change in living beings?";
  }
  
  cerch1_3 = new visual.Polygon({
    win: psychoJS.window, name: 'cerch1_3', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [(- 0.4), 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -1, 
    interpolate: true, 
  });
  
  rett_2 = new visual.Rect ({
    win: psychoJS.window, name: 'rett_2', 
    width: [0.8, 0.07][0], height: [0.8, 0.07][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -2, 
    interpolate: true, 
  });
  
  cerch1_4 = new visual.Polygon({
    win: psychoJS.window, name: 'cerch1_4', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [0.4, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -3, 
    interpolate: true, 
  });
  
  previous = new visual.Slider({
    win: psychoJS.window, name: 'previous',
    startValue: undefined,
    size: [0.8, 0.05], pos: [0, 0], ori: 0.0, units: psychoJS.window.units,
    labels: [0, 100], fontSize: 0.03, ticks: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color(var_colore), markerColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: -4, 
    flip: false,
  });
  
  feedback_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'feedback_3',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.1)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -5.0 
  });
  
  rettok_2 = new visual.Rect ({
    win: psychoJS.window, name: 'rettok_2', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0, (- 0.2)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -6, 
    interpolate: true, 
  });
  
  ok_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ok_4',
    text: taconferma1,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.2)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -7.0 
  });
  
  istr_vd_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_4',
    text: tadomanda1,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -8.0 
  });
  
  istr_vd_5 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_5',
    text: tasp1,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.14], draggable: false, height: 0.025,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -9.0 
  });
  
  istr_vd_6 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_6',
    text: tasp21,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.35)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -10.0 
  });
  
  vd_titolo_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'vd_titolo_2',
    text: tadom1,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.42], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -11.0 
  });
  
  mouse_vd_2 = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_vd_2.mouseClock = new util.Clock();
  // Initialize components for Routine "D_VD2"
  D_VD2Clock = new util.Clock();
  // Run 'Begin Experiment' code from code_vd_4
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  if (_pj.in_es6(group, [1, 3, 5])) {
      taconferma16 = "Conferma";
      tasp16 = "(la scala va da 0 a 100: con 0 che significa 0 su 100, e 100 che significa 100 su 100)";
      tasp216 = "Clicca sulla barra sopra, e vedrai apparire uno slider. Puoi trascinare questo slider su qualsiasi punto della scala. Una volta soddisfatta/o della tua risposta, clicca il pulsante Conferma.";
      taconf16 = "Conferma";
      tadom16 = "Domanda";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          taconferma16 = "Confirm";
          tasp16 = "(the scale ranges from 0 to 100: with 0 being 0 out of 100, and 100 being 100 out of 100)";
          tasp216 = "Click on the bar above, and you will see a slider appear. You can drag this slider to any point on the scale. Once you are satisfied with your answer, click the Confirm button.";
          taconf16 = "Confirm";
          tadom16 = "Question";
      } else {
          throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
      }
  }
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      tadomanda16 = "Al di l\u00e0 del Batatrim, se un farmaco \u00e8 considerato efficace nel guarire i pazienti, quante volte su 100 ti aspetteresti che un paziente guarisca dopo averlo assunto?";
  }
  if ((Number.parseInt(expInfo["group"]) === 2)) {
      tadomanda16 = "Beyond Batatrim, if a drug is considered effective in curing patients, how many times out of 100 would you expect a patient to recover after taking it?";
  }
  if ((Number.parseInt(expInfo["group"]) === 3)) {
      tadomanda16 = "Al di l\u00e0 del sistema NZ-6, se una leva \u00e8 considerata efficace nell'attivare un sistema di sicurezza, quante volte su 100 ti aspetteresti che il macchinario si fermi quando viene attivata?";
  }
  if ((Number.parseInt(expInfo["group"]) === 4)) {
      tadomanda16 = "Beyond the NZ-6 system, if a lever is considered effective in activating a safety system, how many times out of 100 would you expect the machine to stop when the lever is activated?";
  }
  if ((Number.parseInt(expInfo["group"]) === 5)) {
      tadomanda16 = "Al di l\u00e0 del Fluffberry, se qualche frutto \u00e8 considerato efficace nel far cambiare colore agli Yellowpops, quante volte su 100 ti aspetteresti che lo Yellowpop cambi colore dopo averlo mangiato?";
  }
  if ((Number.parseInt(expInfo["group"]) === 6)) {
      tadomanda16 = "Beyond the Fluffberry, if some fruit is considered effective in changing the color of Yellowpops, how many times out of 100 would you expect the Yellowpop to change color after eating it?";
  }
  
  cerch1_5 = new visual.Polygon({
    win: psychoJS.window, name: 'cerch1_5', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [(- 0.4), 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -1, 
    interpolate: true, 
  });
  
  rett_3 = new visual.Rect ({
    win: psychoJS.window, name: 'rett_3', 
    width: [0.8, 0.07][0], height: [0.8, 0.07][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -2, 
    interpolate: true, 
  });
  
  cerch1_6 = new visual.Polygon({
    win: psychoJS.window, name: 'cerch1_6', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [0.4, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -3, 
    interpolate: true, 
  });
  
  previous_2 = new visual.Slider({
    win: psychoJS.window, name: 'previous_2',
    startValue: undefined,
    size: [0.8, 0.05], pos: [0, 0], ori: 0.0, units: psychoJS.window.units,
    labels: [0, 100], fontSize: 0.03, ticks: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color(var_colore), markerColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: -4, 
    flip: false,
  });
  
  feedback_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'feedback_4',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.1)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -5.0 
  });
  
  rettok_3 = new visual.Rect ({
    win: psychoJS.window, name: 'rettok_3', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0, (- 0.2)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -6, 
    interpolate: true, 
  });
  
  ok_5 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ok_5',
    text: taconferma16,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.2)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -7.0 
  });
  
  istr_vd_7 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_7',
    text: tadomanda16,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -8.0 
  });
  
  istr_vd_8 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_8',
    text: tasp16,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.14], draggable: false, height: 0.025,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -9.0 
  });
  
  istr_vd_9 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_9',
    text: tasp216,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.35)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -10.0 
  });
  
  vd_titolo_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'vd_titolo_3',
    text: tadom16,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.42], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -11.0 
  });
  
  mouse_vd_3 = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_vd_3.mouseClock = new util.Clock();
  // Initialize components for Routine "D_VD3"
  D_VD3Clock = new util.Clock();
  // Run 'Begin Experiment' code from code_vd_5
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  if (_pj.in_es6(group, [1, 3, 5])) {
      taconferma167 = "Conferma";
      tasp167 = "(la scala va da 0 a 100: con 0 che significa 0 su 100, e 100 che significa 100 su 100)";
      tasp2167 = "Clicca sulla barra sopra, e vedrai apparire uno slider. Puoi trascinare questo slider su qualsiasi punto della scala. Una volta soddisfatta/o della tua risposta, clicca il pulsante Conferma.";
      taconf167 = "Conferma";
      tadom167 = "Domanda";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          taconferma167 = "Confirm";
          tasp167 = "(the scale ranges from 0 to 100: with 0 being 0 out of 100, and 100 being 100 out of 100)";
          tasp2167 = "Click on the bar above, and you will see a slider appear. You can drag this slider to any point on the scale. Once you are satisfied with your answer, click the Confirm button.";
          taconf167 = "Confirm";
          tadom167 = "Question";
      } else {
          throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
      }
  }
  if ((Number.parseInt(expInfo["group"]) === 1)) {
      tadomanda167 = "Al di l\u00e0 del Batatrim, se un farmaco \u00e8 considerato efficace nel guarire i pazienti, quante volte su 100 ti aspetteresti che un paziente guarisca dopo NON averlo assunto?";
  } else {
      if ((Number.parseInt(expInfo["group"]) === 2)) {
          tadomanda167 = "Beyond Batatrim, if a drug is considered effective in curing patients, how many times out of 100 would you expect a patient to recover after NOT taking it?";
      } else {
          if ((Number.parseInt(expInfo["group"]) === 3)) {
              tadomanda167 = "Al di l\u00e0 del sistema NZ-6, se una leva \u00e8 considerata efficace nell'attivare un sistema di sicurezza, quante volte su 100 ti aspetteresti che il macchinario si fermi quando NON viene attivata?";
          } else {
              if ((Number.parseInt(expInfo["group"]) === 4)) {
                  tadomanda167 = "Beyond the NZ-6 system, if a lever is considered effective in activating a safety system, how many times out of 100 would you expect the machine to stop when the lever is NOT activated?";
              } else {
                  if ((Number.parseInt(expInfo["group"]) === 5)) {
                      tadomanda167 = "Al di l\u00e0 del Fluffberry, se qualche frutto \u00e8 considerato efficace nel far cambiare colore agli Yellowpops, quante volte su 100 ti aspetteresti che lo Yellowpop cambi colore dopo NON averlo mangiato?";
                  } else {
                      if ((Number.parseInt(expInfo["group"]) === 6)) {
                          tadomanda167 = "Beyond the Fluffberry, if some fruit is considered effective in changing the color of Yellowpops, how many times out of 100 would you expect the Yellowpop to change color after NOT eating it?";
                      }
                  }
              }
          }
      }
  }
  
  cerch1_7 = new visual.Polygon({
    win: psychoJS.window, name: 'cerch1_7', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [(- 0.4), 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -1, 
    interpolate: true, 
  });
  
  rett_4 = new visual.Rect ({
    win: psychoJS.window, name: 'rett_4', 
    width: [0.8, 0.07][0], height: [0.8, 0.07][1],
    ori: 0.0, 
    pos: [0, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -2, 
    interpolate: true, 
  });
  
  cerch1_8 = new visual.Polygon({
    win: psychoJS.window, name: 'cerch1_8', 
    edges: 100, size:[0.07, 0.07],
    ori: 0.0, 
    pos: [0.4, 0], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 1.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -3, 
    interpolate: true, 
  });
  
  previous_3 = new visual.Slider({
    win: psychoJS.window, name: 'previous_3',
    startValue: undefined,
    size: [0.8, 0.05], pos: [0, 0], ori: 0.0, units: psychoJS.window.units,
    labels: [0, 100], fontSize: 0.03, ticks: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100],
    granularity: 1.0, style: ["RATING"],
    color: new util.Color(var_colore), markerColor: new util.Color([(- 1.0), (- 1.0), (- 1.0)]), lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    opacity: undefined, fontFamily: 'Arial', bold: true, italic: false, depth: -4, 
    flip: false,
  });
  
  feedback_5 = new visual.TextStim({
    win: psychoJS.window,
    name: 'feedback_5',
    text: '',
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.1)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -5.0 
  });
  
  rettok_4 = new visual.Rect ({
    win: psychoJS.window, name: 'rettok_4', 
    width: [0.2, 0.1][0], height: [0.2, 0.1][1],
    ori: 0.0, 
    pos: [0, (- 0.2)], 
    draggable: false, 
    anchor: 'center', 
    lineWidth: 4.0, 
    lineColor: new util.Color([0.6549, 0.6549, 0.6549]), 
    fillColor: new util.Color('white'), 
    colorSpace: 'rgb', 
    opacity: undefined, 
    depth: -6, 
    interpolate: true, 
  });
  
  ok_6 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ok_6',
    text: taconferma167,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.2)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -7.0 
  });
  
  istr_vd_10 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_10',
    text: tadomanda167,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.25], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -8.0 
  });
  
  istr_vd_11 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_11',
    text: tasp167,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.14], draggable: false, height: 0.025,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -9.0 
  });
  
  istr_vd_12 = new visual.TextStim({
    win: psychoJS.window,
    name: 'istr_vd_12',
    text: tasp2167,
    font: var_testo,
    units: undefined, 
    pos: [0, (- 0.35)], draggable: false, height: 0.03,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -10.0 
  });
  
  vd_titolo_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'vd_titolo_4',
    text: tadom167,
    font: var_testo,
    units: undefined, 
    pos: [0, 0.42], draggable: false, height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color(var_colore),  opacity: undefined,
    depth: -11.0 
  });
  
  mouse_vd_4 = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_vd_4.mouseClock = new util.Clock();
  // Initialize components for Routine "Ant_lastquestion"
  Ant_lastquestionClock = new util.Clock();
  textino = new visual.TextStim({
    win: psychoJS.window,
    name: 'textino',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], draggable: false, height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: 0.0 
  });
  
  // Run 'Begin Experiment' code from code_8
  var _pj;
  function _pj_snippets(container) {
      function in_es6(left, right) {
          if (((right instanceof Array) || ((typeof right) === "string"))) {
              return (right.indexOf(left) > (- 1));
          } else {
              if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                  return right.has(left);
              } else {
                  return (left in right);
              }
          }
      }
      container["in_es6"] = in_es6;
      return container;
  }
  _pj = {};
  _pj_snippets(_pj);
  if (_pj.in_es6(group, [1, 3, 5])) {
      finalT = "Attendi qualche secondo per essere reindirizzata/o alla pagina finale.";
  } else {
      if (_pj.in_es6(group, [2, 4, 6])) {
          finalT = "Please wait a few seconds to be redirected to the final page.";
      } else {
          throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
      }
  }
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var AlfaMaxDurationReached;
var gotValidClick;
var AlfaMaxDuration;
var AlfaComponents;
function AlfaRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'Alfa' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    AlfaClock.reset();
    routineTimer.reset();
    AlfaMaxDurationReached = false;
    // update component parameters for each repeat
    // setup some python lists for storing info about the alfa_mouse
    alfa_mouse.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('Alfa.started', globalClock.getTime());
    AlfaMaxDuration = null
    // keep track of which components have finished
    AlfaComponents = [];
    AlfaComponents.push(alfa_linea);
    AlfaComponents.push(alfa_testo2);
    AlfaComponents.push(alfa_testo1);
    AlfaComponents.push(alfa_image2);
    AlfaComponents.push(alfa_image1);
    AlfaComponents.push(alfa_mask);
    AlfaComponents.push(alfa_clicca);
    AlfaComponents.push(alfa_mouse);
    
    for (const thisComponent of AlfaComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var prevButtonState;
var _mouseButtons;
function AlfaRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'Alfa' ---
    // get current time
    t = AlfaClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *alfa_linea* updates
    if (t >= 0.0 && alfa_linea.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      alfa_linea.tStart = t;  // (not accounting for frame time here)
      alfa_linea.frameNStart = frameN;  // exact frame index
      
      alfa_linea.setAutoDraw(true);
    }
    
    
    // *alfa_testo2* updates
    if (t >= 0.0 && alfa_testo2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      alfa_testo2.tStart = t;  // (not accounting for frame time here)
      alfa_testo2.frameNStart = frameN;  // exact frame index
      
      alfa_testo2.setAutoDraw(true);
    }
    
    
    // *alfa_testo1* updates
    if (t >= 0.0 && alfa_testo1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      alfa_testo1.tStart = t;  // (not accounting for frame time here)
      alfa_testo1.frameNStart = frameN;  // exact frame index
      
      alfa_testo1.setAutoDraw(true);
    }
    
    
    // *alfa_image2* updates
    if (t >= 0.0 && alfa_image2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      alfa_image2.tStart = t;  // (not accounting for frame time here)
      alfa_image2.frameNStart = frameN;  // exact frame index
      
      alfa_image2.setAutoDraw(true);
    }
    
    
    // *alfa_image1* updates
    if (t >= 0.0 && alfa_image1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      alfa_image1.tStart = t;  // (not accounting for frame time here)
      alfa_image1.frameNStart = frameN;  // exact frame index
      
      alfa_image1.setAutoDraw(true);
    }
    
    
    // *alfa_mask* updates
    if (t >= 0.0 && alfa_mask.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      alfa_mask.tStart = t;  // (not accounting for frame time here)
      alfa_mask.frameNStart = frameN;  // exact frame index
      
      alfa_mask.setAutoDraw(true);
    }
    
    
    if (alfa_clicca.status === PsychoJS.Status.STARTED){ // only update if being drawn
      alfa_clicca.setColor(new util.Color([Math.sin(t), (- 1.0), (- 1.0)]), false);
    }
    
    // *alfa_clicca* updates
    if (t >= 0 && alfa_clicca.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      alfa_clicca.tStart = t;  // (not accounting for frame time here)
      alfa_clicca.frameNStart = frameN;  // exact frame index
      
      alfa_clicca.setAutoDraw(true);
    }
    
    // *alfa_mouse* updates
    if (t >= 0.0 && alfa_mouse.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      alfa_mouse.tStart = t;  // (not accounting for frame time here)
      alfa_mouse.frameNStart = frameN;  // exact frame index
      
      alfa_mouse.status = PsychoJS.Status.STARTED;
      alfa_mouse.mouseClock.reset();
      prevButtonState = alfa_mouse.getPressed();  // if button is down already this ISN'T a new click
      }
    if (alfa_mouse.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = alfa_mouse.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          alfa_mouse.clickableObjects = eval(alfa_mask)
          ;// make sure the mouse's clickable objects are an array
          if (!Array.isArray(alfa_mouse.clickableObjects)) {
              alfa_mouse.clickableObjects = [alfa_mouse.clickableObjects];
          }
          // iterate through clickable objects and check each
          for (const obj of alfa_mouse.clickableObjects) {
              if (obj.contains(alfa_mouse)) {
                  gotValidClick = true;
                  alfa_mouse.clicked_name.push(obj.name);
              }
          }
          if (!gotValidClick) {
              alfa_mouse.clicked_name.push(null);
          }
          if (gotValidClick === true) { // end routine on response
            continueRoutine = false;
          }
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of AlfaComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var _mouseXYs;
function AlfaRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'Alfa' ---
    for (const thisComponent of AlfaComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('Alfa.stopped', globalClock.getTime());
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = alfa_mouse.getPos();
    _mouseButtons = alfa_mouse.getPressed();
    psychoJS.experiment.addData('alfa_mouse.x', _mouseXYs[0]);
    psychoJS.experiment.addData('alfa_mouse.y', _mouseXYs[1]);
    psychoJS.experiment.addData('alfa_mouse.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('alfa_mouse.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('alfa_mouse.rightButton', _mouseButtons[2]);
    if (alfa_mouse.clicked_name.length > 0) {
      psychoJS.experiment.addData('alfa_mouse.clicked_name', alfa_mouse.clicked_name[0]);}
    // the Routine "Alfa" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var ITIMaxDurationReached;
var ITIMaxDuration;
var ITIComponents;
function ITIRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'ITI' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    ITIClock.reset();
    routineTimer.reset();
    ITIMaxDurationReached = false;
    // update component parameters for each repeat
    psychoJS.experiment.addData('ITI.started', globalClock.getTime());
    ITIMaxDuration = null
    // keep track of which components have finished
    ITIComponents = [];
    ITIComponents.push(ITI_fig);
    
    for (const thisComponent of ITIComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function ITIRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'ITI' ---
    // get current time
    t = ITIClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *ITI_fig* updates
    if (t >= 0 && ITI_fig.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ITI_fig.tStart = t;  // (not accounting for frame time here)
      ITI_fig.frameNStart = frameN;  // exact frame index
      
      ITI_fig.setAutoDraw(true);
    }
    
    if (ITI_fig.status === PsychoJS.Status.STARTED && frameN >= 60) {
      ITI_fig.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of ITIComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ITIRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'ITI' ---
    for (const thisComponent of ITIComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('ITI.stopped', globalClock.getTime());
    // the Routine "ITI" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var B_consensoinformatoMaxDurationReached;
var consenso;
var cons_go;
var cons_hid;
var cons_msg;
var cons_opaav;
var cons_opain;
var go_on;
var tempo_consenso;
var B_consensoinformatoMaxDuration;
var B_consensoinformatoComponents;
function B_consensoinformatoRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'B_consensoinformato' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    B_consensoinformatoClock.reset();
    routineTimer.reset();
    B_consensoinformatoMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from cons_code
    consenso = 2;
    cons_go = 1;
    cons_hid = 0;
    cons_msg = null;
    cons_opaav = 1;
    cons_opain = 0.5;
    cons_text.setAlignHoriz("left");
    go_on = 0;
    tempo_consenso = t;
    
    // setup some python lists for storing info about the cons_mouse
    cons_mouse.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('B_consensoinformato.started', globalClock.getTime());
    B_consensoinformatoMaxDuration = null
    // keep track of which components have finished
    B_consensoinformatoComponents = [];
    B_consensoinformatoComponents.push(cons_tit);
    B_consensoinformatoComponents.push(cons_indietro);
    B_consensoinformatoComponents.push(cons_avanti);
    B_consensoinformatoComponents.push(cons_avvio);
    B_consensoinformatoComponents.push(cons_noavvio);
    B_consensoinformatoComponents.push(cons_avviotext);
    B_consensoinformatoComponents.push(cons_avviotext_3);
    B_consensoinformatoComponents.push(cons_text);
    B_consensoinformatoComponents.push(cons_nr_pag);
    B_consensoinformatoComponents.push(cons_nr_pag_2);
    B_consensoinformatoComponents.push(cons_nr_pag_3);
    B_consensoinformatoComponents.push(cons_av_text);
    B_consensoinformatoComponents.push(cons_in_text);
    B_consensoinformatoComponents.push(cons_mouse);
    
    for (const thisComponent of B_consensoinformatoComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function B_consensoinformatoRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'B_consensoinformato' ---
    // get current time
    t = B_consensoinformatoClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from cons_code
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    if ((cons_hid > 0)) {
        cons_hid = (cons_hid - 0.05);
    }
    if ((cons_hid <= 0)) {
        if (cons_mouse.isPressedIn(cons_avanti)) {
            cons_go = (cons_go + 1);
            cons_hid = 1;
        } else {
            if (cons_mouse.isPressedIn(cons_indietro)) {
                cons_go = (cons_go - 1);
                cons_hid = 1;
            }
        }
    }
    if ((cons_go > 3)) {
        cons_go = 3;
    }
    if ((cons_go < 1)) {
        cons_go = 1;
    }
    if ((cons_go === 2)) {
        if (_pj.in_es6(group, [1, 3, 5])) {
            cons_msg = (((("    Dichiari:" + "\n\n- Di essere maggiorenne.") + "\n\n- Di essere a conoscenza che lo studio \u00e8 conforme alle leggi vigenti (Decreto Legislativo 196/2003 e GDPR UE 679/2016) riguardo la protezione dei dati, e che acconsenti al trattamento e alla comunicazione dei dati personali,") + " nei limiti, per le finalit\u00e0 e per la durata specificate dalla normativa vigente (Decreto Legislativo 196/2003 e GDPR UE 679/2016). Il responsabile della ricerca si impegna a rispettare gli obblighi previsti dalla legislazione") + " riguardo la raccolta, il trattamento e la conservazione dei dati sensibili.");
        }
        if (_pj.in_es6(group, [2, 4, 6])) {
            cons_msg = (((("    You hereby declare:" + "\n\n- That you are of legal age.") + "\n\n- That you acknowledge the study complies with current legislation (Legislative Decree 196/2003 and GDPR EU 679/2016) regarding data protection, and that you consent to the processing and communication of personal data,") + " within the limits, purposes, and duration specified by current legislation (Legislative Decree 196/2003 and GDPR EU 679/2016). The research coordinator commits to respecting the obligations set by law") + " regarding the collection, processing, and storage of sensitive data.");
        }
        cons_opaav = 1;
        cons_opain = 1;
    } else {
        if ((cons_go === 3)) {
            if (_pj.in_es6(group, [1, 3, 5])) {
                cons_msg = ((("- Di essere a conoscenza che puoi ritirarti dallo studio in qualsiasi momento senza dover fornire spiegazioni, senza alcuna penalit\u00e0, e garantendo che i tuoi dati non vengano utilizzati." + "\n\n- Di essere a conoscenza che i dati saranno raccolti in modo anonimo e associati a un codice che permetter\u00e0 solo al partecipante di accedere ai propri dati.") + "\n\n- Di essere a conoscenza che i tuoi dati saranno utilizzati esclusivamente per scopi scientifici e statistici, nel rispetto delle regole di riservatezza.") + "\n\n  Premi 'Accetta' per acconsentire e proseguire. Premi 'Rifiuta' altrimenti.");
            }
            if (_pj.in_es6(group, [2, 4, 6])) {
                cons_msg = ((("- You acknowledge that you can withdraw from the study at any time without providing any explanation, without penalty, and ensuring that your data will not be used." + "\n\n- You acknowledge that the data will be collected anonymously and associated with a code that only the participant can use to access their own data.") + "\n\n- You acknowledge that your data will be used exclusively for scientific and statistical purposes, in compliance with confidentiality rules.") + "\n\n  Press 'Accept' to consent and continue. Press 'Reject' otherwise.");
            }
            cons_opaav = 0.5;
            cons_opain = 1;
        } else {
            if ((cons_go === 1)) {
                if (_pj.in_es6(group, [1, 3, 5])) {
                    cons_msg = ((("    Gentile partecipante, chiediamo il tuo consenso per prendere parte a questa ricerca.\n\n" + "Lo scopo di questa ricerca \u00e8 capire l'effetto che il contesto ha sulle nostre decisioni.") + "\n\nLa durata totale dell'esperimento sar\u00e0 di circa 20 minuti.") + "\n\nTi verranno presentati dei paragrafi e delle frasi da leggere a cui dovrai rispondere.");
                }
                if (_pj.in_es6(group, [2, 4, 6])) {
                    cons_msg = ((("    Dear participant, we ask for your consent to take part in this research.\n\n" + "The purpose of this research is to understand the effect that context has on our decisions.") + "\n\nThe total duration of the experiment will be about 20 minutes.") + "\n\nYou will be presented with paragraphs and sentences to read and respond to.");
                }
                cons_opaav = 1;
                cons_opain = 0.5;
            }
        }
    }
    if ((cons_avvio.status === PsychoJS.Status.STARTED)) {
        if (cons_mouse.isPressedIn(cons_avvio)) {
            consenso = 1;
            continueRoutine = false;
        } else {
            if (cons_mouse.isPressedIn(cons_noavvio)) {
                consenso = 0;
                continueRoutine = false;
            }
        }
    }
    tempo_consenso = t;
    
    
    // *cons_tit* updates
    if (t >= 0.0 && cons_tit.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_tit.tStart = t;  // (not accounting for frame time here)
      cons_tit.frameNStart = frameN;  // exact frame index
      
      cons_tit.setAutoDraw(true);
    }
    
    
    if (cons_indietro.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_indietro.setOpacity(cons_opain, false);
    }
    
    // *cons_indietro* updates
    if (t >= 0.0 && cons_indietro.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_indietro.tStart = t;  // (not accounting for frame time here)
      cons_indietro.frameNStart = frameN;  // exact frame index
      
      cons_indietro.setAutoDraw(true);
    }
    
    
    if (cons_avanti.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_avanti.setOpacity(cons_opaav, false);
    }
    
    // *cons_avanti* updates
    if (t >= 0.0 && cons_avanti.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_avanti.tStart = t;  // (not accounting for frame time here)
      cons_avanti.frameNStart = frameN;  // exact frame index
      
      cons_avanti.setAutoDraw(true);
    }
    
    
    // *cons_avvio* updates
    if (((cons_go == 3)) && cons_avvio.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_avvio.tStart = t;  // (not accounting for frame time here)
      cons_avvio.frameNStart = frameN;  // exact frame index
      
      cons_avvio.setAutoDraw(true);
    }
    
    
    // *cons_noavvio* updates
    if (((cons_go == 3)) && cons_noavvio.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_noavvio.tStart = t;  // (not accounting for frame time here)
      cons_noavvio.frameNStart = frameN;  // exact frame index
      
      cons_noavvio.setAutoDraw(true);
    }
    
    
    // *cons_avviotext* updates
    if (((cons_go == 3)) && cons_avviotext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_avviotext.tStart = t;  // (not accounting for frame time here)
      cons_avviotext.frameNStart = frameN;  // exact frame index
      
      cons_avviotext.setAutoDraw(true);
    }
    
    
    // *cons_avviotext_3* updates
    if (((cons_go == 3)) && cons_avviotext_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_avviotext_3.tStart = t;  // (not accounting for frame time here)
      cons_avviotext_3.frameNStart = frameN;  // exact frame index
      
      cons_avviotext_3.setAutoDraw(true);
    }
    
    
    if (cons_text.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_text.setText(cons_msg, false);
    }
    
    // *cons_text* updates
    if (t >= 0.0 && cons_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_text.tStart = t;  // (not accounting for frame time here)
      cons_text.frameNStart = frameN;  // exact frame index
      
      cons_text.setAutoDraw(true);
    }
    
    
    if (cons_nr_pag.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_nr_pag.setText(cons_go, false);
    }
    
    // *cons_nr_pag* updates
    if (t >= 0.0 && cons_nr_pag.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_nr_pag.tStart = t;  // (not accounting for frame time here)
      cons_nr_pag.frameNStart = frameN;  // exact frame index
      
      cons_nr_pag.setAutoDraw(true);
    }
    
    
    if (cons_nr_pag_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_nr_pag_2.setText('/', false);
    }
    
    // *cons_nr_pag_2* updates
    if (t >= 0.0 && cons_nr_pag_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_nr_pag_2.tStart = t;  // (not accounting for frame time here)
      cons_nr_pag_2.frameNStart = frameN;  // exact frame index
      
      cons_nr_pag_2.setAutoDraw(true);
    }
    
    
    if (cons_nr_pag_3.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_nr_pag_3.setText('3', false);
    }
    
    // *cons_nr_pag_3* updates
    if (t >= 0.0 && cons_nr_pag_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_nr_pag_3.tStart = t;  // (not accounting for frame time here)
      cons_nr_pag_3.frameNStart = frameN;  // exact frame index
      
      cons_nr_pag_3.setAutoDraw(true);
    }
    
    
    if (cons_av_text.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_av_text.setOpacity(cons_opaav, false);
    }
    
    // *cons_av_text* updates
    if (t >= 0.0 && cons_av_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_av_text.tStart = t;  // (not accounting for frame time here)
      cons_av_text.frameNStart = frameN;  // exact frame index
      
      cons_av_text.setAutoDraw(true);
    }
    
    
    if (cons_in_text.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_in_text.setOpacity(cons_opain, false);
    }
    
    // *cons_in_text* updates
    if (t >= 0.0 && cons_in_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_in_text.tStart = t;  // (not accounting for frame time here)
      cons_in_text.frameNStart = frameN;  // exact frame index
      
      cons_in_text.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of B_consensoinformatoComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var loop1;
function B_consensoinformatoRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'B_consensoinformato' ---
    for (const thisComponent of B_consensoinformatoComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('B_consensoinformato.stopped', globalClock.getTime());
    // Run 'End Routine' code from cons_code
    if ((go_on > 40)) {
        loop1 = 1;
    }
    if ((go_on <= 40)) {
        loop1 = 0;
    }
    psychoJS.experiment.addData("tempo_consenso", tempo_consenso);
    
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = cons_mouse.getPos();
    _mouseButtons = cons_mouse.getPressed();
    psychoJS.experiment.addData('cons_mouse.x', _mouseXYs[0]);
    psychoJS.experiment.addData('cons_mouse.y', _mouseXYs[1]);
    psychoJS.experiment.addData('cons_mouse.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('cons_mouse.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('cons_mouse.rightButton', _mouseButtons[2]);
    if (cons_mouse.clicked_name.length > 0) {
      psychoJS.experiment.addData('cons_mouse.clicked_name', cons_mouse.clicked_name[0]);}
    // the Routine "B_consensoinformato" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var exp_loop;
function exp_loopLoopBegin(exp_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    exp_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: consenso, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'exp_loop'
    });
    psychoJS.experiment.addLoop(exp_loop); // add the loop to the experiment
    currentLoop = exp_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisExp_loop of exp_loop) {
      snapshot = exp_loop.getSnapshot();
      exp_loopLoopScheduler.add(importConditions(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(A_benvenutoRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(A_benvenutoRoutineEachFrame());
      exp_loopLoopScheduler.add(A_benvenutoRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(B2_istruzioniRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(B2_istruzioniRoutineEachFrame());
      exp_loopLoopScheduler.add(B2_istruzioniRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(SAMevaluationRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(SAMevaluationRoutineEachFrame());
      exp_loopLoopScheduler.add(SAMevaluationRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(LoadingRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(LoadingRoutineEachFrame());
      exp_loopLoopScheduler.add(LoadingRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      const trialsLoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trialsLoopBegin(trialsLoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trialsLoopScheduler);
      exp_loopLoopScheduler.add(trialsLoopEnd);
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(loadingquestionRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(loadingquestionRoutineEachFrame());
      exp_loopLoopScheduler.add(loadingquestionRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(VD_dualRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(VD_dualRoutineEachFrame());
      exp_loopLoopScheduler.add(VD_dualRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(D_VDRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(D_VDRoutineEachFrame());
      exp_loopLoopScheduler.add(D_VDRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      const trials_3LoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trials_3LoopBegin(trials_3LoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trials_3LoopScheduler);
      exp_loopLoopScheduler.add(trials_3LoopEnd);
      const trials_4LoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trials_4LoopBegin(trials_4LoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trials_4LoopScheduler);
      exp_loopLoopScheduler.add(trials_4LoopEnd);
      const trials_5LoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trials_5LoopBegin(trials_5LoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trials_5LoopScheduler);
      exp_loopLoopScheduler.add(trials_5LoopEnd);
      const trials_6LoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trials_6LoopBegin(trials_6LoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trials_6LoopScheduler);
      exp_loopLoopScheduler.add(trials_6LoopEnd);
      const trials_7LoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trials_7LoopBegin(trials_7LoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trials_7LoopScheduler);
      exp_loopLoopScheduler.add(trials_7LoopEnd);
      const trials_8LoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trials_8LoopBegin(trials_8LoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trials_8LoopScheduler);
      exp_loopLoopScheduler.add(trials_8LoopEnd);
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(PreviousRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(PreviousRoutineEachFrame());
      exp_loopLoopScheduler.add(PreviousRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(D_VD2RoutineBegin(snapshot));
      exp_loopLoopScheduler.add(D_VD2RoutineEachFrame());
      exp_loopLoopScheduler.add(D_VD2RoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(D_VD3RoutineBegin(snapshot));
      exp_loopLoopScheduler.add(D_VD3RoutineEachFrame());
      exp_loopLoopScheduler.add(D_VD3RoutineEnd(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      const trials_9LoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trials_9LoopBegin(trials_9LoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trials_9LoopScheduler);
      exp_loopLoopScheduler.add(trials_9LoopEnd);
      const trials_10LoopScheduler = new Scheduler(psychoJS);
      exp_loopLoopScheduler.add(trials_10LoopBegin(trials_10LoopScheduler, snapshot));
      exp_loopLoopScheduler.add(trials_10LoopScheduler);
      exp_loopLoopScheduler.add(trials_10LoopEnd);
      exp_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(ITIRoutineEachFrame());
      exp_loopLoopScheduler.add(ITIRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(Ant_lastquestionRoutineBegin(snapshot));
      exp_loopLoopScheduler.add(Ant_lastquestionRoutineEachFrame());
      exp_loopLoopScheduler.add(Ant_lastquestionRoutineEnd(snapshot));
      exp_loopLoopScheduler.add(exp_loopLoopEndIteration(exp_loopLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


var trials;
function trialsLoopBegin(trialsLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: conditionFile,
      seed: undefined, name: 'trials'
    });
    psychoJS.experiment.addLoop(trials); // add the loop to the experiment
    currentLoop = trials;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial of trials) {
      snapshot = trials.getSnapshot();
      trialsLoopScheduler.add(importConditions(snapshot));
      trialsLoopScheduler.add(C_associative_taskRoutineBegin(snapshot));
      trialsLoopScheduler.add(C_associative_taskRoutineEachFrame());
      trialsLoopScheduler.add(C_associative_taskRoutineEnd(snapshot));
      trialsLoopScheduler.add(trialsLoopEndIteration(trialsLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trialsLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trialsLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_3;
function trials_3LoopBegin(trials_3LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_3 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: survey1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'trials_3'
    });
    psychoJS.experiment.addLoop(trials_3); // add the loop to the experiment
    currentLoop = trials_3;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_3 of trials_3) {
      snapshot = trials_3.getSnapshot();
      trials_3LoopScheduler.add(importConditions(snapshot));
      trials_3LoopScheduler.add(SUP1RoutineBegin(snapshot));
      trials_3LoopScheduler.add(SUP1RoutineEachFrame());
      trials_3LoopScheduler.add(SUP1RoutineEnd(snapshot));
      trials_3LoopScheduler.add(trials_3LoopEndIteration(trials_3LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_3LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_3);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_3LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_4;
function trials_4LoopBegin(trials_4LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_4 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: survey2, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'trials_4'
    });
    psychoJS.experiment.addLoop(trials_4); // add the loop to the experiment
    currentLoop = trials_4;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_4 of trials_4) {
      snapshot = trials_4.getSnapshot();
      trials_4LoopScheduler.add(importConditions(snapshot));
      trials_4LoopScheduler.add(SUP2RoutineBegin(snapshot));
      trials_4LoopScheduler.add(SUP2RoutineEachFrame());
      trials_4LoopScheduler.add(SUP2RoutineEnd(snapshot));
      trials_4LoopScheduler.add(trials_4LoopEndIteration(trials_4LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_4LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_4);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_4LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_5;
function trials_5LoopBegin(trials_5LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_5 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: survey3, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'trials_5'
    });
    psychoJS.experiment.addLoop(trials_5); // add the loop to the experiment
    currentLoop = trials_5;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_5 of trials_5) {
      snapshot = trials_5.getSnapshot();
      trials_5LoopScheduler.add(importConditions(snapshot));
      trials_5LoopScheduler.add(SUP3RoutineBegin(snapshot));
      trials_5LoopScheduler.add(SUP3RoutineEachFrame());
      trials_5LoopScheduler.add(SUP3RoutineEnd(snapshot));
      trials_5LoopScheduler.add(trials_5LoopEndIteration(trials_5LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_5LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_5);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_5LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_6;
function trials_6LoopBegin(trials_6LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_6 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: survey4, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'trials_6'
    });
    psychoJS.experiment.addLoop(trials_6); // add the loop to the experiment
    currentLoop = trials_6;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_6 of trials_6) {
      snapshot = trials_6.getSnapshot();
      trials_6LoopScheduler.add(importConditions(snapshot));
      trials_6LoopScheduler.add(SUP4RoutineBegin(snapshot));
      trials_6LoopScheduler.add(SUP4RoutineEachFrame());
      trials_6LoopScheduler.add(SUP4RoutineEnd(snapshot));
      trials_6LoopScheduler.add(trials_6LoopEndIteration(trials_6LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_6LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_6);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_6LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_7;
function trials_7LoopBegin(trials_7LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_7 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: survey5, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'trials_7'
    });
    psychoJS.experiment.addLoop(trials_7); // add the loop to the experiment
    currentLoop = trials_7;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_7 of trials_7) {
      snapshot = trials_7.getSnapshot();
      trials_7LoopScheduler.add(importConditions(snapshot));
      trials_7LoopScheduler.add(SUP5RoutineBegin(snapshot));
      trials_7LoopScheduler.add(SUP5RoutineEachFrame());
      trials_7LoopScheduler.add(SUP5RoutineEnd(snapshot));
      trials_7LoopScheduler.add(trials_7LoopEndIteration(trials_7LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_7LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_7);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_7LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_8;
function trials_8LoopBegin(trials_8LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_8 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: survey6, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'trials_8'
    });
    psychoJS.experiment.addLoop(trials_8); // add the loop to the experiment
    currentLoop = trials_8;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_8 of trials_8) {
      snapshot = trials_8.getSnapshot();
      trials_8LoopScheduler.add(importConditions(snapshot));
      trials_8LoopScheduler.add(SUP6RoutineBegin(snapshot));
      trials_8LoopScheduler.add(SUP6RoutineEachFrame());
      trials_8LoopScheduler.add(SUP6RoutineEnd(snapshot));
      trials_8LoopScheduler.add(trials_8LoopEndIteration(trials_8LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_8LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_8);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_8LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_9;
function trials_9LoopBegin(trials_9LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_9 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: esteng, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'trials_9'
    });
    psychoJS.experiment.addLoop(trials_9); // add the loop to the experiment
    currentLoop = trials_9;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_9 of trials_9) {
      snapshot = trials_9.getSnapshot();
      trials_9LoopScheduler.add(importConditions(snapshot));
      trials_9LoopScheduler.add(DERoutineBegin(snapshot));
      trials_9LoopScheduler.add(DERoutineEachFrame());
      trials_9LoopScheduler.add(DERoutineEnd(snapshot));
      trials_9LoopScheduler.add(YoERoutineBegin(snapshot));
      trials_9LoopScheduler.add(YoERoutineEachFrame());
      trials_9LoopScheduler.add(YoERoutineEnd(snapshot));
      trials_9LoopScheduler.add(trials_9LoopEndIteration(trials_9LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_9LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_9);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_9LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_10;
function trials_10LoopBegin(trials_10LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_10 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: estita, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'trials_10'
    });
    psychoJS.experiment.addLoop(trials_10); // add the loop to the experiment
    currentLoop = trials_10;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_10 of trials_10) {
      snapshot = trials_10.getSnapshot();
      trials_10LoopScheduler.add(importConditions(snapshot));
      trials_10LoopScheduler.add(DIRoutineBegin(snapshot));
      trials_10LoopScheduler.add(DIRoutineEachFrame());
      trials_10LoopScheduler.add(DIRoutineEnd(snapshot));
      trials_10LoopScheduler.add(YoIRoutineBegin(snapshot));
      trials_10LoopScheduler.add(YoIRoutineEachFrame());
      trials_10LoopScheduler.add(YoIRoutineEnd(snapshot));
      trials_10LoopScheduler.add(trials_10LoopEndIteration(trials_10LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_10LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_10);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_10LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


async function exp_loopLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(exp_loop);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function exp_loopLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var A_benvenutoMaxDurationReached;
var ben_linea;
var A_benvenutoMaxDuration;
var A_benvenutoComponents;
function A_benvenutoRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'A_benvenuto' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    A_benvenutoClock.reset();
    routineTimer.reset();
    A_benvenutoMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from ben_code
    ben_linea = 0;
    
    // setup some python lists for storing info about the ben_mouse
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('A_benvenuto.started', globalClock.getTime());
    A_benvenutoMaxDuration = null
    // keep track of which components have finished
    A_benvenutoComponents = [];
    A_benvenutoComponents.push(ben_testo_1);
    A_benvenutoComponents.push(ben_testo_2);
    A_benvenutoComponents.push(ben_qdr_2);
    A_benvenutoComponents.push(ben_qdr_1);
    A_benvenutoComponents.push(ben_qdrtno_1);
    A_benvenutoComponents.push(ben_qdrtno_2);
    A_benvenutoComponents.push(ben_qdrtno_3);
    A_benvenutoComponents.push(ben_qdrtno_4);
    A_benvenutoComponents.push(ben_mouse);
    A_benvenutoComponents.push(ben_linea_sx);
    A_benvenutoComponents.push(ben_linea_dx);
    
    for (const thisComponent of A_benvenutoComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function A_benvenutoRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'A_benvenuto' ---
    // get current time
    t = A_benvenutoClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from ben_code
    if ((ben_linea >= 0.4)) {
        ben_linea = 0.4;
    } else {
        ben_linea = (t / 8);
    }
    
    
    if (ben_testo_1.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_testo_1.setOpacity(0+t/2, false);
    }
    
    // *ben_testo_1* updates
    if (t >= 0 && ben_testo_1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_testo_1.tStart = t;  // (not accounting for frame time here)
      ben_testo_1.frameNStart = frameN;  // exact frame index
      
      ben_testo_1.setAutoDraw(true);
    }
    
    
    if (ben_testo_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_testo_2.setColor(new util.Color([Math.sin(t), (- 1.0), (- 1.0)]), false);
      ben_testo_2.setOpacity(0+t/2, false);
    }
    
    // *ben_testo_2* updates
    if (t >= 0 && ben_testo_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_testo_2.tStart = t;  // (not accounting for frame time here)
      ben_testo_2.frameNStart = frameN;  // exact frame index
      
      ben_testo_2.setAutoDraw(true);
    }
    
    
    if (ben_qdr_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_qdr_2.setOpacity(0+t/2, false);
    }
    
    // *ben_qdr_2* updates
    if (t >= 0.0 && ben_qdr_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_qdr_2.tStart = t;  // (not accounting for frame time here)
      ben_qdr_2.frameNStart = frameN;  // exact frame index
      
      ben_qdr_2.setAutoDraw(true);
    }
    
    
    if (ben_qdr_1.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_qdr_1.setOpacity(0+t/2, false);
    }
    
    // *ben_qdr_1* updates
    if (t >= 0.0 && ben_qdr_1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_qdr_1.tStart = t;  // (not accounting for frame time here)
      ben_qdr_1.frameNStart = frameN;  // exact frame index
      
      ben_qdr_1.setAutoDraw(true);
    }
    
    
    if (ben_qdrtno_1.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_qdrtno_1.setOpacity(0+t/2, false);
    }
    
    // *ben_qdrtno_1* updates
    if (t >= 0 && ben_qdrtno_1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_qdrtno_1.tStart = t;  // (not accounting for frame time here)
      ben_qdrtno_1.frameNStart = frameN;  // exact frame index
      
      ben_qdrtno_1.setAutoDraw(true);
    }
    
    
    if (ben_qdrtno_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_qdrtno_2.setOpacity(0+t/2, false);
    }
    
    // *ben_qdrtno_2* updates
    if (t >= 0 && ben_qdrtno_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_qdrtno_2.tStart = t;  // (not accounting for frame time here)
      ben_qdrtno_2.frameNStart = frameN;  // exact frame index
      
      ben_qdrtno_2.setAutoDraw(true);
    }
    
    
    if (ben_qdrtno_3.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_qdrtno_3.setOpacity(0+t/2, false);
    }
    
    // *ben_qdrtno_3* updates
    if (t >= 0.0 && ben_qdrtno_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_qdrtno_3.tStart = t;  // (not accounting for frame time here)
      ben_qdrtno_3.frameNStart = frameN;  // exact frame index
      
      ben_qdrtno_3.setAutoDraw(true);
    }
    
    
    if (ben_qdrtno_4.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_qdrtno_4.setOpacity(0+t/2, false);
    }
    
    // *ben_qdrtno_4* updates
    if (t >= 0.0 && ben_qdrtno_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_qdrtno_4.tStart = t;  // (not accounting for frame time here)
      ben_qdrtno_4.frameNStart = frameN;  // exact frame index
      
      ben_qdrtno_4.setAutoDraw(true);
    }
    
    // *ben_mouse* updates
    if (t >= 2.0 && ben_mouse.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_mouse.tStart = t;  // (not accounting for frame time here)
      ben_mouse.frameNStart = frameN;  // exact frame index
      
      ben_mouse.status = PsychoJS.Status.STARTED;
      ben_mouse.mouseClock.reset();
      prevButtonState = ben_mouse.getPressed();  // if button is down already this ISN'T a new click
      }
    if (ben_mouse.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = ben_mouse.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // end routine on response
          continueRoutine = false;
        }
      }
    }
    
    if (ben_linea_sx.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_linea_sx.setSize([ben_linea, 0.005], false);
    }
    
    // *ben_linea_sx* updates
    if (t >= 0.0 && ben_linea_sx.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_linea_sx.tStart = t;  // (not accounting for frame time here)
      ben_linea_sx.frameNStart = frameN;  // exact frame index
      
      ben_linea_sx.setAutoDraw(true);
    }
    
    
    if (ben_linea_dx.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ben_linea_dx.setSize([ben_linea, 0.005], false);
    }
    
    // *ben_linea_dx* updates
    if (t >= 0.0 && ben_linea_dx.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ben_linea_dx.tStart = t;  // (not accounting for frame time here)
      ben_linea_dx.frameNStart = frameN;  // exact frame index
      
      ben_linea_dx.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of A_benvenutoComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function A_benvenutoRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'A_benvenuto' ---
    for (const thisComponent of A_benvenutoComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('A_benvenuto.stopped', globalClock.getTime());
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = ben_mouse.getPos();
    _mouseButtons = ben_mouse.getPressed();
    psychoJS.experiment.addData('ben_mouse.x', _mouseXYs[0]);
    psychoJS.experiment.addData('ben_mouse.y', _mouseXYs[1]);
    psychoJS.experiment.addData('ben_mouse.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('ben_mouse.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('ben_mouse.rightButton', _mouseButtons[2]);
    // the Routine "A_benvenuto" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var B2_istruzioniMaxDurationReached;
var tempo_istru;
var B2_istruzioniMaxDuration;
var B2_istruzioniComponents;
function B2_istruzioniRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'B2_istruzioni' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    B2_istruzioniClock.reset();
    routineTimer.reset();
    B2_istruzioniMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from cons_code_2
    cons_go = 1;
    cons_hid = 0;
    cons_msg = null;
    cons_opaav = 1;
    cons_opain = 0.5;
    cons_text_2.setAlignHoriz("left");
    go_on = 0;
    tempo_istru = t;
    
    // setup some python lists for storing info about the cons_mouse_2
    cons_mouse_2.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('B2_istruzioni.started', globalClock.getTime());
    B2_istruzioniMaxDuration = null
    // keep track of which components have finished
    B2_istruzioniComponents = [];
    B2_istruzioniComponents.push(cons_tit_2);
    B2_istruzioniComponents.push(cons_indietro_2);
    B2_istruzioniComponents.push(cons_avanti_2);
    B2_istruzioniComponents.push(cons_avvio_2);
    B2_istruzioniComponents.push(cons_avviotext_2);
    B2_istruzioniComponents.push(cons_text_2);
    B2_istruzioniComponents.push(cons_nr_pag_4);
    B2_istruzioniComponents.push(cons_nr_pag_5);
    B2_istruzioniComponents.push(cons_nr_pag_6);
    B2_istruzioniComponents.push(cons_av_text_2);
    B2_istruzioniComponents.push(cons_in_text_2);
    B2_istruzioniComponents.push(cons_mouse_2);
    
    for (const thisComponent of B2_istruzioniComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function B2_istruzioniRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'B2_istruzioni' ---
    // get current time
    t = B2_istruzioniClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from cons_code_2
    if ((cons_hid > 0)) {
        cons_hid = (cons_hid - 0.05);
    }
    if ((cons_hid <= 0)) {
        if (cons_mouse.isPressedIn(cons_avanti)) {
            cons_go = (cons_go + 1);
            cons_hid = 1;
        } else {
            if (cons_mouse.isPressedIn(cons_indietro)) {
                cons_go = (cons_go - 1);
                cons_hid = 1;
            }
        }
    }
    if ((cons_go > 3)) {
        cons_go = 3;
    }
    if ((cons_go < 1)) {
        cons_go = 1;
    }
    group = Number.parseInt(expInfo["group"]);
    if ((cons_go === 1)) {
        if ((group === 1)) {
            cons_msg = ((("Immagina di essere un medico/a che lavora nel pronto soccorso di un ospedale.\n" + " Sei uno/a specialista in una malattia rara e pericolosa chiamata 'Sindrome di Lindsay', che deve essere trattata rapidamente in pronto soccorso.") + "\n\n Le crisi indotte da questa malattia possono essere fermate immediatamente con un farmaco chiamato 'Batatrim',") + " che \u00e8 ancora in fase di sperimentazione.");
        } else {
            if ((group === 2)) {
                cons_msg = ((("Imagine you are a doctor working in the emergency room of a hospital.\n" + " You are a specialist in a rare and dangerous disease called 'Lindsay Syndrome', which must be treated quickly in the emergency room.") + "\n\n Crises induced by this disease can be stopped immediately with a medicine called 'Batatrim',") + " which is still in the testing stage.");
            } else {
                if ((group === 3)) {
                    cons_msg = "Immagina di lavorare come ingegnere/a meccanico presso una grande azienda che produce macchine industriali.\nSei uno/a specialista nella gestione di un macchinario detto 'Laminatorix', che necessita di essere fermato manualmente in caso di sovraccarico.\n\n Il macchinario pu\u00f2 essere fermato azionando una leva che attiva un sistema di sicurezza chiamato 'NZ-6', che \u00e8 ancora in fase di sperimentazione.";
                } else {
                    if ((group === 4)) {
                        cons_msg = "Imagine you work as a mechanical engineer at a large company that produces industrial machinery.\nYou specialize in managing a machine called the 'Laminatorix', which needs to be manually stopped in case of overload.\n\n The machine can be stopped by activating a lever that triggers a safety system called 'NZ-6', which is still experimental.";
                    } else {
                        if ((group === 5)) {
                            cons_msg = "Immagina di essere un esploratore/un'esploratrice dell'Universo.\nTi trovi nel pianeta 'Yellowland', abitato da misteriose creature gialle chiamate 'Yellowpops'. Noti che talvolta gli 'Yellowpops' cambiano colore, diventando verdi.\n\n Noti anche che talvolta gli Yellowpops si nutrono di un frutto chiamato 'Fluffberry'. Ti stai chiedendo se il Fluffberry sia collegato al cambio di colore degli Yellowpops.";
                        } else {
                            if ((group === 6)) {
                                cons_msg = "Imagine you are an explorer of the Universe.\nYou find yourself on the planet 'Yellowland,' inhabited by mysterious yellow creatures called 'Yellowpops.' You notice that sometimes the Yellowpops change color, turning green.\n\n You also notice that sometimes the Yellowpops eat a fruit called 'Fluffberry.' You wonder if the Fluffberry is connected to the Yellowpops' color change.";
                            }
                        }
                    }
                }
            }
        }
        cons_opaav = 1;
        cons_opain = 0.5;
    } else {
        if ((cons_go === 2)) {
            if ((group === 1)) {
                cons_msg = (((("In seguito, ti verranno presentate una serie di cartelle cliniche di pazienti che soffrono della Sindrome di Lindsay.\n" + " In ogni cartella, prima vedrai se il paziente ha preso il Batatrim o no, e ti verr\u00e0 chiesto di indicare se pensi che il paziente si riprender\u00e0 dalla crisi o meno.") + " Poi, vedrai se il paziente si \u00e8 effettivamente ripreso dalla crisi o meno.") + "\n\n Cerca di determinare se il Batatrim \u00e8 realmente efficace nel curare le crisi. Una volta che avrai visto un certo numero di cartelle cliniche,") + " ti verranno fatte alcune domande.");
            } else {
                if ((group === 2)) {
                    cons_msg = (((("Next, you will be presented with a series of medical records of patients suffering from Lindsay Syndrome.\n" + " In each record, you will first see whether the patient had taken Batatrim or not, and you will be asked to indicate whether you think the patient will recover from the crisis or not.") + " Then, you will see whether the patient actually recovered from the crisis or not.") + "\n\n Try to find out if Batatrim is actually effective in recovering from crises. Once you have seen a number of medical records,") + " you will be asked a few questions.");
                } else {
                    if ((group === 3)) {
                        cons_msg = "In seguito, ti verranno presentati i registri di una serie di aziende che si sono trovate a gestire situazioni di sovraccarico del Laminatorix.\nIn ogni registro, vedrai prima se la leva del sistema NZ-6 \u00e8 stata azionata o no, e ti verr\u00e0 chiesto di indicare se pensi che il Laminatorix si fermer\u00e0 o meno.Successivamente, vedrai se il Laminatorix si \u00e8 effettivamente fermato o meno.\n\n Cerca di determinare se il sistema NZ-6 \u00e8 realmente efficace nel fermare il Laminatorix. Una volta che avrai visto un certo numero di registri, ti verranno fatte alcune domande.";
                    } else {
                        if ((group === 4)) {
                            cons_msg = "Next, you will be presented with a series of records from companies that have dealt with overload situations on the Laminatorix.\nIn each record, you will first see whether the NZ-6 lever was activated or not, and you will be asked to indicate whether you think the Laminatorix will stop or not.Then, you will see whether the Laminatorix actually stopped or not.\n\n Try to determine if the NZ-6 system is actually effective in stopping the Laminatorix. After reviewing a number of records, you will be asked a few questions.";
                        } else {
                            if ((group === 5)) {
                                cons_msg = "In seguito, ti verranno presentati i registri di una serie di osservazioni fatte sul pianeta Yellowland.\nIn ogni registro, vedrai prima se lo Yellowpop ha mangiato il Fluffberry o no, e ti verr\u00e0 chiesto di indicare se pensi che lo Yellowpop cambier\u00e0 colore o meno.Successivamente, vedrai se lo Yellowpop ha effettivamente cambiato colore o meno.\n\n Cerca di determinare se il Fluffberry \u00e8 realmente efficace nel far cambiare colore agli Yellowpops. Una volta che avrai visto un certo numero di registri, ti verranno fatte alcune domande.";
                            } else {
                                if ((group === 6)) {
                                    cons_msg = "Next, you will be presented with a series of records from observations made on the planet Yellowland.\nIn each record, you will first see whether the Yellowpop ate the Fluffberry or not, and you will be asked to indicate whether you think the Yellowpop will change color or not.Afterwards, you will see if the Yellowpop actually changed color or not.\n\n Try to determine if the Fluffberry is actually effective in changing the Yellowpops' color. Once you have seen a number of records, you will be asked a few questions.";
                                }
                            }
                        }
                    }
                }
            }
            cons_opaav = 1;
            cons_opain = 1;
        } else {
            if ((cons_go === 3)) {
                if ((group === 1)) {
                    cons_msg = (("Prima di iniziare l\u2019osservazione di queste cartelle cliniche ti verr\u00e0 presentata una domanda relativa alla storia che hai appena letto." + "\n\n Se hai capito le istruzioni e sei pronto per iniziare, premi il pulsante 'Continua' qui sotto.") + "\n\n Altrimenti, premi 'Indietro' per leggere di nuovo.");
                } else {
                    if ((group === 2)) {
                        cons_msg = (("Before you begin reviewing these medical records, you will be asked a question related to the story you have just read." + "\n\n If you have understood the instructions and are ready to begin, press the 'Continue' button below.") + "\n\n Otherwise, press 'Back' to read again.");
                    } else {
                        if ((group === 3)) {
                            cons_msg = "Prima di iniziare l\u2019osservazione di questi registri, ti verr\u00e0 presentata una domanda relativa alla storia che hai appena letto.\n\n Se hai capito le istruzioni e sei pronto/a per iniziare, premi il pulsante 'Continua' qui sotto.\n\n Altrimenti, premi 'Indietro' per leggere di nuovo.";
                        } else {
                            if ((group === 4)) {
                                cons_msg = "Before you begin reviewing these records, you will be asked a question related to the story you have just read.\n\n If you have understood the instructions and are ready to begin, press the 'Continue' button below.\n\n Otherwise, press 'Back' to read again.";
                            } else {
                                if ((group === 5)) {
                                    cons_msg = "Prima di iniziare l\u2019osservazione di questi registri, ti verr\u00e0 presentata una domanda relativa alla storia che hai appena letto.\n\n Se hai capito le istruzioni e sei pronto/a per iniziare, premi il pulsante 'Continua' qui sotto.\n\n Altrimenti, premi 'Indietro' per leggere di nuovo.";
                                } else {
                                    if ((group === 6)) {
                                        cons_msg = "Before you begin reviewing these records, you will be asked a question related to the story you have just read.\n\n If you have understood the instructions and are ready to begin, press the 'Continue' button below.\n\n Otherwise, press 'Back' to read again.";
                                    }
                                }
                            }
                        }
                    }
                }
                cons_opaav = 0.5;
                cons_opain = 1;
            }
        }
    }
    if ((cons_avvio_2.status === PsychoJS.Status.STARTED)) {
        if (cons_mouse.isPressedIn(cons_avvio_2)) {
            continueRoutine = false;
        }
    }
    tempo_istru = t;
    
    
    // *cons_tit_2* updates
    if (t >= 0.0 && cons_tit_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_tit_2.tStart = t;  // (not accounting for frame time here)
      cons_tit_2.frameNStart = frameN;  // exact frame index
      
      cons_tit_2.setAutoDraw(true);
    }
    
    
    if (cons_indietro_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_indietro_2.setOpacity(cons_opain, false);
    }
    
    // *cons_indietro_2* updates
    if (t >= 0.0 && cons_indietro_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_indietro_2.tStart = t;  // (not accounting for frame time here)
      cons_indietro_2.frameNStart = frameN;  // exact frame index
      
      cons_indietro_2.setAutoDraw(true);
    }
    
    
    if (cons_avanti_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_avanti_2.setOpacity(cons_opaav, false);
    }
    
    // *cons_avanti_2* updates
    if (t >= 0.0 && cons_avanti_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_avanti_2.tStart = t;  // (not accounting for frame time here)
      cons_avanti_2.frameNStart = frameN;  // exact frame index
      
      cons_avanti_2.setAutoDraw(true);
    }
    
    
    // *cons_avvio_2* updates
    if (((cons_go == 3)) && cons_avvio_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_avvio_2.tStart = t;  // (not accounting for frame time here)
      cons_avvio_2.frameNStart = frameN;  // exact frame index
      
      cons_avvio_2.setAutoDraw(true);
    }
    
    
    // *cons_avviotext_2* updates
    if (((cons_go == 3)) && cons_avviotext_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_avviotext_2.tStart = t;  // (not accounting for frame time here)
      cons_avviotext_2.frameNStart = frameN;  // exact frame index
      
      cons_avviotext_2.setAutoDraw(true);
    }
    
    
    if (cons_text_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_text_2.setText(cons_msg, false);
    }
    
    // *cons_text_2* updates
    if (t >= 0.0 && cons_text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_text_2.tStart = t;  // (not accounting for frame time here)
      cons_text_2.frameNStart = frameN;  // exact frame index
      
      cons_text_2.setAutoDraw(true);
    }
    
    
    if (cons_nr_pag_4.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_nr_pag_4.setText(cons_go, false);
    }
    
    // *cons_nr_pag_4* updates
    if (t >= 0.0 && cons_nr_pag_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_nr_pag_4.tStart = t;  // (not accounting for frame time here)
      cons_nr_pag_4.frameNStart = frameN;  // exact frame index
      
      cons_nr_pag_4.setAutoDraw(true);
    }
    
    
    if (cons_nr_pag_5.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_nr_pag_5.setText('/', false);
    }
    
    // *cons_nr_pag_5* updates
    if (t >= 0.0 && cons_nr_pag_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_nr_pag_5.tStart = t;  // (not accounting for frame time here)
      cons_nr_pag_5.frameNStart = frameN;  // exact frame index
      
      cons_nr_pag_5.setAutoDraw(true);
    }
    
    
    if (cons_nr_pag_6.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_nr_pag_6.setText('3', false);
    }
    
    // *cons_nr_pag_6* updates
    if (t >= 0.0 && cons_nr_pag_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_nr_pag_6.tStart = t;  // (not accounting for frame time here)
      cons_nr_pag_6.frameNStart = frameN;  // exact frame index
      
      cons_nr_pag_6.setAutoDraw(true);
    }
    
    
    if (cons_av_text_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_av_text_2.setOpacity(cons_opaav, false);
    }
    
    // *cons_av_text_2* updates
    if (t >= 0.0 && cons_av_text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_av_text_2.tStart = t;  // (not accounting for frame time here)
      cons_av_text_2.frameNStart = frameN;  // exact frame index
      
      cons_av_text_2.setAutoDraw(true);
    }
    
    
    if (cons_in_text_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      cons_in_text_2.setOpacity(cons_opain, false);
    }
    
    // *cons_in_text_2* updates
    if (t >= 0.0 && cons_in_text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cons_in_text_2.tStart = t;  // (not accounting for frame time here)
      cons_in_text_2.frameNStart = frameN;  // exact frame index
      
      cons_in_text_2.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of B2_istruzioniComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function B2_istruzioniRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'B2_istruzioni' ---
    for (const thisComponent of B2_istruzioniComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('B2_istruzioni.stopped', globalClock.getTime());
    // Run 'End Routine' code from cons_code_2
    psychoJS.experiment.addData("tempo_istru", tempo_istru);
    
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = cons_mouse_2.getPos();
    _mouseButtons = cons_mouse_2.getPressed();
    psychoJS.experiment.addData('cons_mouse_2.x', _mouseXYs[0]);
    psychoJS.experiment.addData('cons_mouse_2.y', _mouseXYs[1]);
    psychoJS.experiment.addData('cons_mouse_2.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('cons_mouse_2.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('cons_mouse_2.rightButton', _mouseButtons[2]);
    if (cons_mouse_2.clicked_name.length > 0) {
      psychoJS.experiment.addData('cons_mouse_2.clicked_name', cons_mouse_2.clicked_name[0]);}
    // the Routine "B2_istruzioni" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SAMevaluationMaxDurationReached;
var SAMM;
var temposam;
var colorSAMvalence;
var colorSAMintensity;
var SAMevaluationMaxDuration;
var SAMevaluationComponents;
function SAMevaluationRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SAMevaluation' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    SAMevaluationClock.reset();
    routineTimer.reset();
    SAMevaluationMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_6
    SAMM = 0;
    temposam = 0;
    colorSAMvalence = [(- 1), (- 1), (- 1)];
    colorSAMintensity = [(- 1), (- 1), (- 1)];
    
    sliderintensity.reset()
    slidervalence.reset()
    // setup some python lists for storing info about the mouse_sam
    // current position of the mouse:
    mouse_sam.x = [];
    mouse_sam.y = [];
    mouse_sam.leftButton = [];
    mouse_sam.midButton = [];
    mouse_sam.rightButton = [];
    mouse_sam.time = [];
    mouse_sam.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('SAMevaluation.started', globalClock.getTime());
    SAMevaluationMaxDuration = null
    // keep track of which components have finished
    SAMevaluationComponents = [];
    SAMevaluationComponents.push(intensity);
    SAMevaluationComponents.push(valence);
    SAMevaluationComponents.push(cercvalence);
    SAMevaluationComponents.push(cerchvalence2);
    SAMevaluationComponents.push(Rett_slider_valence);
    SAMevaluationComponents.push(titoloSAM);
    SAMevaluationComponents.push(istr_SAM);
    SAMevaluationComponents.push(istr_sam2);
    SAMevaluationComponents.push(rettsliderintensity);
    SAMevaluationComponents.push(cercintensity);
    SAMevaluationComponents.push(cercintensity2);
    SAMevaluationComponents.push(sliderintensity);
    SAMevaluationComponents.push(rettoksam);
    SAMevaluationComponents.push(slidervalence);
    SAMevaluationComponents.push(ok_3);
    SAMevaluationComponents.push(mouse_sam);
    
    for (const thisComponent of SAMevaluationComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function SAMevaluationRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'SAMevaluation' ---
    // get current time
    t = SAMevaluationClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_6
    if ((isNaN(slidervalence.rating) || isNaN(sliderintensity.rating))) {
        SAMM = 0;
    } else {
        SAMM = 1;
    }
    if ((rettoksam.status === PsychoJS.Status.STARTED)) {
        if (mouse_vd.isPressedIn(rettoksam)) {
            continueRoutine = false;
        }
    }
    temposam = t;
    
    
    // *intensity* updates
    if (t >= 0.0 && intensity.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      intensity.tStart = t;  // (not accounting for frame time here)
      intensity.frameNStart = frameN;  // exact frame index
      
      intensity.setAutoDraw(true);
    }
    
    
    // *valence* updates
    if (t >= 0.0 && valence.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      valence.tStart = t;  // (not accounting for frame time here)
      valence.frameNStart = frameN;  // exact frame index
      
      valence.setAutoDraw(true);
    }
    
    
    // *cercvalence* updates
    if (t >= 0.0 && cercvalence.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cercvalence.tStart = t;  // (not accounting for frame time here)
      cercvalence.frameNStart = frameN;  // exact frame index
      
      cercvalence.setAutoDraw(true);
    }
    
    
    // *cerchvalence2* updates
    if (t >= 0.0 && cerchvalence2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerchvalence2.tStart = t;  // (not accounting for frame time here)
      cerchvalence2.frameNStart = frameN;  // exact frame index
      
      cerchvalence2.setAutoDraw(true);
    }
    
    
    // *Rett_slider_valence* updates
    if (t >= 0.0 && Rett_slider_valence.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Rett_slider_valence.tStart = t;  // (not accounting for frame time here)
      Rett_slider_valence.frameNStart = frameN;  // exact frame index
      
      Rett_slider_valence.setAutoDraw(true);
    }
    
    
    // *titoloSAM* updates
    if (t >= 0.0 && titoloSAM.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      titoloSAM.tStart = t;  // (not accounting for frame time here)
      titoloSAM.frameNStart = frameN;  // exact frame index
      
      titoloSAM.setAutoDraw(true);
    }
    
    
    // *istr_SAM* updates
    if (t >= 0.0 && istr_SAM.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_SAM.tStart = t;  // (not accounting for frame time here)
      istr_SAM.frameNStart = frameN;  // exact frame index
      
      istr_SAM.setAutoDraw(true);
    }
    
    
    // *istr_sam2* updates
    if (t >= 0.0 && istr_sam2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_sam2.tStart = t;  // (not accounting for frame time here)
      istr_sam2.frameNStart = frameN;  // exact frame index
      
      istr_sam2.setAutoDraw(true);
    }
    
    
    // *rettsliderintensity* updates
    if (t >= 0.0 && rettsliderintensity.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rettsliderintensity.tStart = t;  // (not accounting for frame time here)
      rettsliderintensity.frameNStart = frameN;  // exact frame index
      
      rettsliderintensity.setAutoDraw(true);
    }
    
    
    // *cercintensity* updates
    if (t >= 0.0 && cercintensity.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cercintensity.tStart = t;  // (not accounting for frame time here)
      cercintensity.frameNStart = frameN;  // exact frame index
      
      cercintensity.setAutoDraw(true);
    }
    
    
    // *cercintensity2* updates
    if (t >= 0.0 && cercintensity2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cercintensity2.tStart = t;  // (not accounting for frame time here)
      cercintensity2.frameNStart = frameN;  // exact frame index
      
      cercintensity2.setAutoDraw(true);
    }
    
    
    if (sliderintensity.status === PsychoJS.Status.STARTED){ // only update if being drawn
      sliderintensity.setFillColor(new util.Color(colorSAMintensity), false);
    }
    
    // *sliderintensity* updates
    if (t >= 0.0 && sliderintensity.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sliderintensity.tStart = t;  // (not accounting for frame time here)
      sliderintensity.frameNStart = frameN;  // exact frame index
      
      sliderintensity.setAutoDraw(true);
    }
    
    
    // *rettoksam* updates
    if (((SAMM == 1)) && rettoksam.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rettoksam.tStart = t;  // (not accounting for frame time here)
      rettoksam.frameNStart = frameN;  // exact frame index
      
      rettoksam.setAutoDraw(true);
    }
    
    
    if (slidervalence.status === PsychoJS.Status.STARTED){ // only update if being drawn
      slidervalence.setFillColor(new util.Color(colorSAMvalence), false);
    }
    
    // *slidervalence* updates
    if (t >= 0.0 && slidervalence.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      slidervalence.tStart = t;  // (not accounting for frame time here)
      slidervalence.frameNStart = frameN;  // exact frame index
      
      slidervalence.setAutoDraw(true);
    }
    
    
    // *ok_3* updates
    if (((SAMM == 1)) && ok_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ok_3.tStart = t;  // (not accounting for frame time here)
      ok_3.frameNStart = frameN;  // exact frame index
      
      ok_3.setAutoDraw(true);
    }
    
    // *mouse_sam* updates
    if (t >= 0.0 && mouse_sam.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_sam.tStart = t;  // (not accounting for frame time here)
      mouse_sam.frameNStart = frameN;  // exact frame index
      
      mouse_sam.status = PsychoJS.Status.STARTED;
      mouse_sam.mouseClock.reset();
      prevButtonState = [0, 0, 0];  // if now button is down we will treat as 'new' click
      }
    if (mouse_sam.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_sam.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          mouse_sam.clickableObjects = eval([slidervalence, sliderintensity, rettoksam])
          ;// make sure the mouse's clickable objects are an array
          if (!Array.isArray(mouse_sam.clickableObjects)) {
              mouse_sam.clickableObjects = [mouse_sam.clickableObjects];
          }
          // iterate through clickable objects and check each
          for (const obj of mouse_sam.clickableObjects) {
              if (obj.contains(mouse_sam)) {
                  gotValidClick = true;
                  mouse_sam.clicked_name.push(obj.name);
              }
          }
          if (!gotValidClick) {
              mouse_sam.clicked_name.push(null);
          }
          _mouseXYs = mouse_sam.getPos();
          mouse_sam.x.push(_mouseXYs[0]);
          mouse_sam.y.push(_mouseXYs[1]);
          mouse_sam.leftButton.push(_mouseButtons[0]);
          mouse_sam.midButton.push(_mouseButtons[1]);
          mouse_sam.rightButton.push(_mouseButtons[2]);
          mouse_sam.time.push(mouse_sam.mouseClock.getTime());
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of SAMevaluationComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function SAMevaluationRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SAMevaluation' ---
    for (const thisComponent of SAMevaluationComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('SAMevaluation.stopped', globalClock.getTime());
    // Run 'End Routine' code from code_6
    psychoJS.experiment.addData("temposam", temposam);
    
    psychoJS.experiment.addData('sliderintensity.response', sliderintensity.getRating());
    psychoJS.experiment.addData('sliderintensity.rt', sliderintensity.getRT());
    psychoJS.experiment.addData('slidervalence.response', slidervalence.getRating());
    psychoJS.experiment.addData('slidervalence.rt', slidervalence.getRT());
    // store data for psychoJS.experiment (ExperimentHandler)
    psychoJS.experiment.addData('mouse_sam.x', mouse_sam.x);
    psychoJS.experiment.addData('mouse_sam.y', mouse_sam.y);
    psychoJS.experiment.addData('mouse_sam.leftButton', mouse_sam.leftButton);
    psychoJS.experiment.addData('mouse_sam.midButton', mouse_sam.midButton);
    psychoJS.experiment.addData('mouse_sam.rightButton', mouse_sam.rightButton);
    psychoJS.experiment.addData('mouse_sam.time', mouse_sam.time);
    psychoJS.experiment.addData('mouse_sam.clicked_name', mouse_sam.clicked_name);
    
    // the Routine "SAMevaluation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var LoadingMaxDurationReached;
var LoadingMaxDuration;
var LoadingComponents;
function LoadingRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'Loading' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    LoadingClock.reset(routineTimer.getTime());
    routineTimer.add(7.000000);
    LoadingMaxDurationReached = false;
    // update component parameters for each repeat
    text22.setText(loadreload);
    psychoJS.experiment.addData('Loading.started', globalClock.getTime());
    LoadingMaxDuration = null
    // keep track of which components have finished
    LoadingComponents = [];
    LoadingComponents.push(text22);
    
    for (const thisComponent of LoadingComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function LoadingRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'Loading' ---
    // get current time
    t = LoadingClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text22* updates
    if (t >= 0.0 && text22.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text22.tStart = t;  // (not accounting for frame time here)
      text22.frameNStart = frameN;  // exact frame index
      
      text22.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 7.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (text22.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text22.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of LoadingComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function LoadingRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'Loading' ---
    for (const thisComponent of LoadingComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('Loading.stopped', globalClock.getTime());
    if (LoadingMaxDurationReached) {
        LoadingClock.add(LoadingMaxDuration);
    } else {
        LoadingClock.add(7.000000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var C_associative_taskMaxDurationReached;
var ass;
var assMo2;
var assMo;
var tempo_trial;
var hapremutosi;
var hapremutono;
var contatore;
var check1;
var check2;
var colc1;
var colc2;
var C_associative_taskMaxDuration;
var C_associative_taskComponents;
function C_associative_taskRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'C_associative_task' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    C_associative_taskClock.reset();
    routineTimer.reset();
    C_associative_taskMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_ass
    ass = 0;
    assMo2 = 1;
    assMo = 0;
    tempo_trial = t;
    hapremutosi = 0;
    hapremutono = 0;
    contatore = 0;
    check1 = "\u2713";
    check2 = "\u2713";
    colc1 = [(- 1), (- 0.216), (- 1)];
    colc2 = [(- 1), (- 0.216), (- 1)];
    if ((cond === "c")) {
        check1 = "\u2717";
        colc1 = [0.4, (- 0.73), (- 0.73)];
    }
    if ((cond === "d")) {
        check1 = "\u2717";
        colc1 = [0.4, (- 0.73), (- 0.73)];
    }
    if ((cond === "b")) {
        check2 = "\u2717";
        colc2 = [0.4, (- 0.73), (- 0.73)];
    }
    if ((cond === "d")) {
        check2 = "\u2717";
        colc2 = [0.4, (- 0.73), (- 0.73)];
    }
    
    ass_primo_2.setColor(new util.Color(colc1));
    ass_primo_2.setText(check1);
    ass_primo.setText(causa);
    ass_terzo_2.setColor(new util.Color(colc2));
    ass_terzo_2.setText(check2);
    ass_terzo.setText(effetto);
    // setup some python lists for storing info about the mouse
    mouse.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('C_associative_task.started', globalClock.getTime());
    C_associative_taskMaxDuration = null
    // keep track of which components have finished
    C_associative_taskComponents = [];
    C_associative_taskComponents.push(linea);
    C_associative_taskComponents.push(cerchio_2);
    C_associative_taskComponents.push(cerchio);
    C_associative_taskComponents.push(ass_r1_3);
    C_associative_taskComponents.push(ass_r1_4);
    C_associative_taskComponents.push(ass_r1_2);
    C_associative_taskComponents.push(ass_r1);
    C_associative_taskComponents.push(ass_psi);
    C_associative_taskComponents.push(ass_pno);
    C_associative_taskComponents.push(ass_primo_2);
    C_associative_taskComponents.push(ass_primo);
    C_associative_taskComponents.push(ass_secondo);
    C_associative_taskComponents.push(ass_si);
    C_associative_taskComponents.push(ass_no);
    C_associative_taskComponents.push(ass_terzo_2);
    C_associative_taskComponents.push(ass_terzo);
    C_associative_taskComponents.push(maskuno);
    C_associative_taskComponents.push(mouse);
    
    for (const thisComponent of C_associative_taskComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function C_associative_taskRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'C_associative_task' ---
    // get current time
    t = C_associative_taskClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_ass
    if ((t >= 1)) {
        assMo = (assMo - 0.02);
    }
    if ((t < 1.5)) {
        if (mouse.isPressedIn(ass_psi)) {
            ass = 0;
        }
        if (mouse.isPressedIn(ass_pno)) {
            ass = 0;
        }
    }
    if ((t >= 1.5)) {
        if (mouse.isPressedIn(ass_psi)) {
            ass = 1;
        }
        if (mouse.isPressedIn(ass_pno)) {
            ass = 1;
        }
    }
    if (((contatore <= 0) && (t >= 1.5))) {
        if (mouse.isPressedIn(ass_psi)) {
            hapremutosi = 1;
            contatore = (contatore + 2);
        }
        if (mouse.isPressedIn(ass_pno)) {
            hapremutono = 1;
            contatore = (contatore + 2);
        }
    }
    if ((ass_r1_3.status === PsychoJS.Status.FINISHED)) {
        assMo2 = (assMo2 - 0.05);
    }
    if ((assMo2 <= 0)) {
        continueRoutine = false;
    }
    tempo_trial = t;
    
    
    // *linea* updates
    if (t >= 0.0 && linea.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      linea.tStart = t;  // (not accounting for frame time here)
      linea.frameNStart = frameN;  // exact frame index
      
      linea.setAutoDraw(true);
    }
    
    
    // *cerchio_2* updates
    if (t >= 0.0 && cerchio_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerchio_2.tStart = t;  // (not accounting for frame time here)
      cerchio_2.frameNStart = frameN;  // exact frame index
      
      cerchio_2.setAutoDraw(true);
    }
    
    
    // *cerchio* updates
    if (t >= 0.0 && cerchio.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerchio.tStart = t;  // (not accounting for frame time here)
      cerchio.frameNStart = frameN;  // exact frame index
      
      cerchio.setAutoDraw(true);
    }
    
    
    if (ass_r1_3.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_r1_3.setOpacity(assMo2, false);
    }
    
    // *ass_r1_3* updates
    if (((ass == 1)) && ass_r1_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_r1_3.tStart = t;  // (not accounting for frame time here)
      ass_r1_3.frameNStart = frameN;  // exact frame index
      
      ass_r1_3.setAutoDraw(true);
    }
    
    if (ass_r1_3.status === PsychoJS.Status.STARTED && t >= (ass_r1_3.tStart + 2.0)) {
      ass_r1_3.setAutoDraw(false);
    }
    
    
    if (ass_r1_4.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_r1_4.setOpacity(assMo2, false);
    }
    
    // *ass_r1_4* updates
    if (((ass > 0)) && ass_r1_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_r1_4.tStart = t;  // (not accounting for frame time here)
      ass_r1_4.frameNStart = frameN;  // exact frame index
      
      ass_r1_4.setAutoDraw(true);
    }
    
    
    if (ass_r1_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_r1_2.setOpacity(assMo2, false);
    }
    
    // *ass_r1_2* updates
    if (t >= 0.0 && ass_r1_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_r1_2.tStart = t;  // (not accounting for frame time here)
      ass_r1_2.frameNStart = frameN;  // exact frame index
      
      ass_r1_2.setAutoDraw(true);
    }
    
    
    if (ass_r1.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_r1.setOpacity(assMo2, false);
    }
    
    // *ass_r1* updates
    if (t >= 0.0 && ass_r1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_r1.tStart = t;  // (not accounting for frame time here)
      ass_r1.frameNStart = frameN;  // exact frame index
      
      ass_r1.setAutoDraw(true);
    }
    
    
    if (ass_psi.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_psi.setOpacity(assMo2, false);
    }
    
    // *ass_psi* updates
    if (t >= 0 && ass_psi.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_psi.tStart = t;  // (not accounting for frame time here)
      ass_psi.frameNStart = frameN;  // exact frame index
      
      ass_psi.setAutoDraw(true);
    }
    
    
    if (ass_pno.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_pno.setOpacity(assMo2, false);
    }
    
    // *ass_pno* updates
    if (t >= 0 && ass_pno.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_pno.tStart = t;  // (not accounting for frame time here)
      ass_pno.frameNStart = frameN;  // exact frame index
      
      ass_pno.setAutoDraw(true);
    }
    
    
    if (ass_primo_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_primo_2.setOpacity(assMo2, false);
    }
    
    // *ass_primo_2* updates
    if (t >= 0.0 && ass_primo_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_primo_2.tStart = t;  // (not accounting for frame time here)
      ass_primo_2.frameNStart = frameN;  // exact frame index
      
      ass_primo_2.setAutoDraw(true);
    }
    
    
    if (ass_primo.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_primo.setOpacity(assMo2, false);
    }
    
    // *ass_primo* updates
    if (t >= 0.0 && ass_primo.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_primo.tStart = t;  // (not accounting for frame time here)
      ass_primo.frameNStart = frameN;  // exact frame index
      
      ass_primo.setAutoDraw(true);
    }
    
    
    if (ass_secondo.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_secondo.setOpacity(assMo2, false);
    }
    
    // *ass_secondo* updates
    if (t >= 0.0 && ass_secondo.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_secondo.tStart = t;  // (not accounting for frame time here)
      ass_secondo.frameNStart = frameN;  // exact frame index
      
      ass_secondo.setAutoDraw(true);
    }
    
    
    if (ass_si.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_si.setOpacity(assMo2, false);
    }
    
    // *ass_si* updates
    if (t >= 0 && ass_si.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_si.tStart = t;  // (not accounting for frame time here)
      ass_si.frameNStart = frameN;  // exact frame index
      
      ass_si.setAutoDraw(true);
    }
    
    
    if (ass_no.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_no.setOpacity(assMo2, false);
    }
    
    // *ass_no* updates
    if (t >= 0 && ass_no.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_no.tStart = t;  // (not accounting for frame time here)
      ass_no.frameNStart = frameN;  // exact frame index
      
      ass_no.setAutoDraw(true);
    }
    
    
    if (ass_terzo_2.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_terzo_2.setOpacity(assMo2, false);
    }
    
    // *ass_terzo_2* updates
    if (((ass == 1)) && ass_terzo_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_terzo_2.tStart = t;  // (not accounting for frame time here)
      ass_terzo_2.frameNStart = frameN;  // exact frame index
      
      ass_terzo_2.setAutoDraw(true);
    }
    
    
    if (ass_terzo.status === PsychoJS.Status.STARTED){ // only update if being drawn
      ass_terzo.setOpacity(assMo2, false);
    }
    
    // *ass_terzo* updates
    if (((ass == 1)) && ass_terzo.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_terzo.tStart = t;  // (not accounting for frame time here)
      ass_terzo.frameNStart = frameN;  // exact frame index
      
      ass_terzo.setAutoDraw(true);
    }
    
    
    if (maskuno.status === PsychoJS.Status.STARTED){ // only update if being drawn
      maskuno.setFillColor(new util.Color([1.0, 1.0, 1.0]), false);
      maskuno.setPos([0, assMo], false);
      maskuno.setLineColor(new util.Color([1.0, 1.0, 1.0]), false);
    }
    
    // *maskuno* updates
    if (t >= 0.0 && maskuno.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      maskuno.tStart = t;  // (not accounting for frame time here)
      maskuno.frameNStart = frameN;  // exact frame index
      
      maskuno.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (maskuno.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      maskuno.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of C_associative_taskComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function C_associative_taskRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'C_associative_task' ---
    for (const thisComponent of C_associative_taskComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('C_associative_task.stopped', globalClock.getTime());
    // Run 'End Routine' code from code_ass
    psychoJS.experiment.addData("tempo_trial", tempo_trial);
    psychoJS.experiment.addData("hapremutosi", hapremutosi);
    psychoJS.experiment.addData("hapremutono", hapremutono);
    tempo_tasktot = (tempo_tasktot + tempo_trial);
    psychoJS.experiment.addData("tempo_tasktot", tempo_tasktot);
    
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = mouse.getPos();
    _mouseButtons = mouse.getPressed();
    psychoJS.experiment.addData('mouse.x', _mouseXYs[0]);
    psychoJS.experiment.addData('mouse.y', _mouseXYs[1]);
    psychoJS.experiment.addData('mouse.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('mouse.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('mouse.rightButton', _mouseButtons[2]);
    if (mouse.clicked_name.length > 0) {
      psychoJS.experiment.addData('mouse.clicked_name', mouse.clicked_name[0]);}
    // the Routine "C_associative_task" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var loadingquestionMaxDurationReached;
var loadingquestionMaxDuration;
var loadingquestionComponents;
function loadingquestionRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'loadingquestion' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    loadingquestionClock.reset(routineTimer.getTime());
    routineTimer.add(7.000000);
    loadingquestionMaxDurationReached = false;
    // update component parameters for each repeat
    testload.setText(loadreload2);
    psychoJS.experiment.addData('loadingquestion.started', globalClock.getTime());
    loadingquestionMaxDuration = null
    // keep track of which components have finished
    loadingquestionComponents = [];
    loadingquestionComponents.push(testload);
    
    for (const thisComponent of loadingquestionComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function loadingquestionRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'loadingquestion' ---
    // get current time
    t = loadingquestionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *testload* updates
    if (t >= 0.0 && testload.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      testload.tStart = t;  // (not accounting for frame time here)
      testload.frameNStart = frameN;  // exact frame index
      
      testload.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 7.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (testload.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      testload.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of loadingquestionComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function loadingquestionRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'loadingquestion' ---
    for (const thisComponent of loadingquestionComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('loadingquestion.stopped', globalClock.getTime());
    if (loadingquestionMaxDurationReached) {
        loadingquestionClock.add(loadingquestionMaxDuration);
    } else {
        loadingquestionClock.add(7.000000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var VD_dualMaxDurationReached;
var tempo_vd_dual;
var main_vd_dual;
var VD_dualMaxDuration;
var VD_dualComponents;
function VD_dualRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'VD_dual' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    VD_dualClock.reset();
    routineTimer.reset();
    VD_dualMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_9
    tempo_vd_dual = t;
    main_vd_dual = 0;
    contino = 0;
    
    // setup some python lists for storing info about the mouse_vddual
    // current position of the mouse:
    mouse_vddual.x = [];
    mouse_vddual.y = [];
    mouse_vddual.leftButton = [];
    mouse_vddual.midButton = [];
    mouse_vddual.rightButton = [];
    mouse_vddual.time = [];
    mouse_vddual.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('VD_dual.started', globalClock.getTime());
    VD_dualMaxDuration = null
    // keep track of which components have finished
    VD_dualComponents = [];
    VD_dualComponents.push(vd_dual_titolo);
    VD_dualComponents.push(ass_vdsi);
    VD_dualComponents.push(ass_vdno);
    VD_dualComponents.push(VD_si);
    VD_dualComponents.push(VD_no);
    VD_dualComponents.push(mouse_vddual);
    VD_dualComponents.push(isttr_vdx);
    
    for (const thisComponent of VD_dualComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function VD_dualRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'VD_dual' ---
    // get current time
    t = VD_dualClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_9
    if (mouse_vddual.isPressedIn(ass_vdno)) {
        contino = contino;
        main_vd_dual = 0;
    }
    if (mouse_vddual.isPressedIn(ass_vdsi)) {
        contino = (contino + 1);
        main_vd_dual = 1;
    }
    tempo_vd_dual = t;
    
    
    // *vd_dual_titolo* updates
    if (t >= 0.0 && vd_dual_titolo.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      vd_dual_titolo.tStart = t;  // (not accounting for frame time here)
      vd_dual_titolo.frameNStart = frameN;  // exact frame index
      
      vd_dual_titolo.setAutoDraw(true);
    }
    
    
    // *ass_vdsi* updates
    if (t >= 0 && ass_vdsi.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_vdsi.tStart = t;  // (not accounting for frame time here)
      ass_vdsi.frameNStart = frameN;  // exact frame index
      
      ass_vdsi.setAutoDraw(true);
    }
    
    
    // *ass_vdno* updates
    if (t >= 0 && ass_vdno.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ass_vdno.tStart = t;  // (not accounting for frame time here)
      ass_vdno.frameNStart = frameN;  // exact frame index
      
      ass_vdno.setAutoDraw(true);
    }
    
    
    // *VD_si* updates
    if (t >= 0 && VD_si.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      VD_si.tStart = t;  // (not accounting for frame time here)
      VD_si.frameNStart = frameN;  // exact frame index
      
      VD_si.setAutoDraw(true);
    }
    
    
    // *VD_no* updates
    if (t >= 0 && VD_no.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      VD_no.tStart = t;  // (not accounting for frame time here)
      VD_no.frameNStart = frameN;  // exact frame index
      
      VD_no.setAutoDraw(true);
    }
    
    // *mouse_vddual* updates
    if (t >= 1.0 && mouse_vddual.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_vddual.tStart = t;  // (not accounting for frame time here)
      mouse_vddual.frameNStart = frameN;  // exact frame index
      
      mouse_vddual.status = PsychoJS.Status.STARTED;
      mouse_vddual.mouseClock.reset();
      prevButtonState = mouse_vddual.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_vddual.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_vddual.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          mouse_vddual.clickableObjects = eval([ass_vdsi, ass_vdno])
          ;// make sure the mouse's clickable objects are an array
          if (!Array.isArray(mouse_vddual.clickableObjects)) {
              mouse_vddual.clickableObjects = [mouse_vddual.clickableObjects];
          }
          // iterate through clickable objects and check each
          for (const obj of mouse_vddual.clickableObjects) {
              if (obj.contains(mouse_vddual)) {
                  gotValidClick = true;
                  mouse_vddual.clicked_name.push(obj.name);
              }
          }
          if (!gotValidClick) {
              mouse_vddual.clicked_name.push(null);
          }
          _mouseXYs = mouse_vddual.getPos();
          mouse_vddual.x.push(_mouseXYs[0]);
          mouse_vddual.y.push(_mouseXYs[1]);
          mouse_vddual.leftButton.push(_mouseButtons[0]);
          mouse_vddual.midButton.push(_mouseButtons[1]);
          mouse_vddual.rightButton.push(_mouseButtons[2]);
          mouse_vddual.time.push(mouse_vddual.mouseClock.getTime());
          if (gotValidClick === true) { // end routine on response
            continueRoutine = false;
          }
        }
      }
    }
    
    // *isttr_vdx* updates
    if (t >= 0.0 && isttr_vdx.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      isttr_vdx.tStart = t;  // (not accounting for frame time here)
      isttr_vdx.frameNStart = frameN;  // exact frame index
      
      isttr_vdx.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of VD_dualComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function VD_dualRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'VD_dual' ---
    for (const thisComponent of VD_dualComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('VD_dual.stopped', globalClock.getTime());
    // Run 'End Routine' code from code_9
    psychoJS.experiment.addData("tempo_vd_dual", tempo_vd_dual);
    psychoJS.experiment.addData("main_vd_dual", main_vd_dual);
    
    // store data for psychoJS.experiment (ExperimentHandler)
    psychoJS.experiment.addData('mouse_vddual.x', mouse_vddual.x);
    psychoJS.experiment.addData('mouse_vddual.y', mouse_vddual.y);
    psychoJS.experiment.addData('mouse_vddual.leftButton', mouse_vddual.leftButton);
    psychoJS.experiment.addData('mouse_vddual.midButton', mouse_vddual.midButton);
    psychoJS.experiment.addData('mouse_vddual.rightButton', mouse_vddual.rightButton);
    psychoJS.experiment.addData('mouse_vddual.time', mouse_vddual.time);
    psychoJS.experiment.addData('mouse_vddual.clicked_name', mouse_vddual.clicked_name);
    
    // the Routine "VD_dual" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var D_VDMaxDurationReached;
var punt_int;
var tempo_vd;
var D_VDMaxDuration;
var D_VDComponents;
function D_VDRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'D_VD' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    D_VDClock.reset();
    routineTimer.reset();
    D_VDMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_vd
    punt_int = 0;
    tempo_vd = t;
    if ((contino === 0)) {
        continueRoutine = false;
    }
    
    vd.reset()
    // setup some python lists for storing info about the mouse_vd
    mouse_vd.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('D_VD.started', globalClock.getTime());
    D_VDMaxDuration = null
    // keep track of which components have finished
    D_VDComponents = [];
    D_VDComponents.push(cerch1);
    D_VDComponents.push(rett);
    D_VDComponents.push(cerch1_2);
    D_VDComponents.push(vd);
    D_VDComponents.push(feedback);
    D_VDComponents.push(rettok);
    D_VDComponents.push(ok);
    D_VDComponents.push(istr_vd);
    D_VDComponents.push(istr_vd_3);
    D_VDComponents.push(istr_vd_2);
    D_VDComponents.push(vd_titolo);
    D_VDComponents.push(mouse_vd);
    
    for (const thisComponent of D_VDComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var msg;
function D_VDRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'D_VD' ---
    // get current time
    t = D_VDClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_vd
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    if (isNaN(vd.rating)) {
        if (_pj.in_es6(group, [1, 3, 5])) {
            msg = "Seleziona un valore tra 1 e 10";
        } else {
            msg = "Select a value from 1 to 10";
        }
    } else {
        punt_int = Number.parseInt(vd.rating);
        if (_pj.in_es6(group, [1, 3, 5])) {
            msg = ("Hai selezionato: " + punt_int);
        } else {
            msg = ("You selected: " + punt_int);
        }
    }
    if ((rettok.status === PsychoJS.Status.STARTED)) {
        if (mouse_vd.isPressedIn(rettok)) {
            continueRoutine = false;
        }
    }
    tempo_vd = t;
    
    
    // *cerch1* updates
    if (t >= 0.0 && cerch1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerch1.tStart = t;  // (not accounting for frame time here)
      cerch1.frameNStart = frameN;  // exact frame index
      
      cerch1.setAutoDraw(true);
    }
    
    
    // *rett* updates
    if (t >= 0.0 && rett.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rett.tStart = t;  // (not accounting for frame time here)
      rett.frameNStart = frameN;  // exact frame index
      
      rett.setAutoDraw(true);
    }
    
    
    // *cerch1_2* updates
    if (t >= 0.0 && cerch1_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerch1_2.tStart = t;  // (not accounting for frame time here)
      cerch1_2.frameNStart = frameN;  // exact frame index
      
      cerch1_2.setAutoDraw(true);
    }
    
    
    // *vd* updates
    if (t >= 0.0 && vd.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      vd.tStart = t;  // (not accounting for frame time here)
      vd.frameNStart = frameN;  // exact frame index
      
      vd.setAutoDraw(true);
    }
    
    
    if (feedback.status === PsychoJS.Status.STARTED){ // only update if being drawn
      feedback.setText(msg, false);
    }
    
    // *feedback* updates
    if (t >= 0 && feedback.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      feedback.tStart = t;  // (not accounting for frame time here)
      feedback.frameNStart = frameN;  // exact frame index
      
      feedback.setAutoDraw(true);
    }
    
    
    // *rettok* updates
    if ((vd.rating) && rettok.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rettok.tStart = t;  // (not accounting for frame time here)
      rettok.frameNStart = frameN;  // exact frame index
      
      rettok.setAutoDraw(true);
    }
    
    
    // *ok* updates
    if ((vd.rating) && ok.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ok.tStart = t;  // (not accounting for frame time here)
      ok.frameNStart = frameN;  // exact frame index
      
      ok.setAutoDraw(true);
    }
    
    
    // *istr_vd* updates
    if (t >= 0.0 && istr_vd.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd.tStart = t;  // (not accounting for frame time here)
      istr_vd.frameNStart = frameN;  // exact frame index
      
      istr_vd.setAutoDraw(true);
    }
    
    
    // *istr_vd_3* updates
    if (t >= 0.0 && istr_vd_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_3.tStart = t;  // (not accounting for frame time here)
      istr_vd_3.frameNStart = frameN;  // exact frame index
      
      istr_vd_3.setAutoDraw(true);
    }
    
    
    // *istr_vd_2* updates
    if (t >= 0.0 && istr_vd_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_2.tStart = t;  // (not accounting for frame time here)
      istr_vd_2.frameNStart = frameN;  // exact frame index
      
      istr_vd_2.setAutoDraw(true);
    }
    
    
    // *vd_titolo* updates
    if (t >= 0.0 && vd_titolo.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      vd_titolo.tStart = t;  // (not accounting for frame time here)
      vd_titolo.frameNStart = frameN;  // exact frame index
      
      vd_titolo.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of D_VDComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function D_VDRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'D_VD' ---
    for (const thisComponent of D_VDComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('D_VD.stopped', globalClock.getTime());
    // Run 'End Routine' code from code_vd
    psychoJS.experiment.addData("tempo_vd", tempo_vd);
    
    psychoJS.experiment.addData('vd.response', vd.getRating());
    psychoJS.experiment.addData('vd.rt', vd.getRT());
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = mouse_vd.getPos();
    _mouseButtons = mouse_vd.getPressed();
    psychoJS.experiment.addData('mouse_vd.x', _mouseXYs[0]);
    psychoJS.experiment.addData('mouse_vd.y', _mouseXYs[1]);
    psychoJS.experiment.addData('mouse_vd.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('mouse_vd.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('mouse_vd.rightButton', _mouseButtons[2]);
    if (mouse_vd.clicked_name.length > 0) {
      psychoJS.experiment.addData('mouse_vd.clicked_name', mouse_vd.clicked_name[0]);}
    // the Routine "D_VD" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SUP1;
var SUP1Clock;
function SUP1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SUP1' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'SUP1' ---
    SUP1 = new visual.Survey({
        win: psychoJS.window,
        name: 'SUP1',
        model: 'MedITA.json',
    });
    SUP1Clock = new util.Clock();
    SUP1.setAutoDraw(true);
    SUP1.status = PsychoJS.Status.STARTED;
    SUP1.isFinished = false;
    SUP1.tStart = t;  // (not accounting for frame time here)
    SUP1.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function SUP1RoutineEachFrame() {
  return async function () {
    t = SUP1Clock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if SUP1 is completed, move on
    if (SUP1.isFinished) {
      SUP1.setAutoDraw(false);
      SUP1.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function SUP1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SUP1' ---
    // get data from SUP1
    const SUP1Response =  SUP1.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(SUP1Response, 'SUP1');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SUP2;
var SUP2Clock;
function SUP2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SUP2' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'SUP2' ---
    SUP2 = new visual.Survey({
        win: psychoJS.window,
        name: 'SUP2',
        model: 'MedENG.json',
    });
    SUP2Clock = new util.Clock();
    SUP2.setAutoDraw(true);
    SUP2.status = PsychoJS.Status.STARTED;
    SUP2.isFinished = false;
    SUP2.tStart = t;  // (not accounting for frame time here)
    SUP2.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function SUP2RoutineEachFrame() {
  return async function () {
    t = SUP2Clock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if SUP2 is completed, move on
    if (SUP2.isFinished) {
      SUP2.setAutoDraw(false);
      SUP2.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function SUP2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SUP2' ---
    // get data from SUP2
    const SUP2Response =  SUP2.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(SUP2Response, 'SUP2');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SUP3;
var SUP3Clock;
function SUP3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SUP3' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'SUP3' ---
    SUP3 = new visual.Survey({
        win: psychoJS.window,
        name: 'SUP3',
        model: 'AzITA.json',
    });
    SUP3Clock = new util.Clock();
    SUP3.setAutoDraw(true);
    SUP3.status = PsychoJS.Status.STARTED;
    SUP3.isFinished = false;
    SUP3.tStart = t;  // (not accounting for frame time here)
    SUP3.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function SUP3RoutineEachFrame() {
  return async function () {
    t = SUP3Clock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if SUP3 is completed, move on
    if (SUP3.isFinished) {
      SUP3.setAutoDraw(false);
      SUP3.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function SUP3RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SUP3' ---
    // get data from SUP3
    const SUP3Response =  SUP3.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(SUP3Response, 'SUP3');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SUP4;
var SUP4Clock;
function SUP4RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SUP4' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'SUP4' ---
    SUP4 = new visual.Survey({
        win: psychoJS.window,
        name: 'SUP4',
        model: 'AzENG.json',
    });
    SUP4Clock = new util.Clock();
    SUP4.setAutoDraw(true);
    SUP4.status = PsychoJS.Status.STARTED;
    SUP4.isFinished = false;
    SUP4.tStart = t;  // (not accounting for frame time here)
    SUP4.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function SUP4RoutineEachFrame() {
  return async function () {
    t = SUP4Clock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if SUP4 is completed, move on
    if (SUP4.isFinished) {
      SUP4.setAutoDraw(false);
      SUP4.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function SUP4RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SUP4' ---
    // get data from SUP4
    const SUP4Response =  SUP4.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(SUP4Response, 'SUP4');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SUP5;
var SUP5Clock;
function SUP5RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SUP5' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'SUP5' ---
    SUP5 = new visual.Survey({
        win: psychoJS.window,
        name: 'SUP5',
        model: 'FlITA.json',
    });
    SUP5Clock = new util.Clock();
    SUP5.setAutoDraw(true);
    SUP5.status = PsychoJS.Status.STARTED;
    SUP5.isFinished = false;
    SUP5.tStart = t;  // (not accounting for frame time here)
    SUP5.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function SUP5RoutineEachFrame() {
  return async function () {
    t = SUP5Clock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if SUP5 is completed, move on
    if (SUP5.isFinished) {
      SUP5.setAutoDraw(false);
      SUP5.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function SUP5RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SUP5' ---
    // get data from SUP5
    const SUP5Response =  SUP5.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(SUP5Response, 'SUP5');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var SUP6;
var SUP6Clock;
function SUP6RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'SUP6' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'SUP6' ---
    SUP6 = new visual.Survey({
        win: psychoJS.window,
        name: 'SUP6',
        model: 'FlENG.json',
    });
    SUP6Clock = new util.Clock();
    SUP6.setAutoDraw(true);
    SUP6.status = PsychoJS.Status.STARTED;
    SUP6.isFinished = false;
    SUP6.tStart = t;  // (not accounting for frame time here)
    SUP6.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function SUP6RoutineEachFrame() {
  return async function () {
    t = SUP6Clock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if SUP6 is completed, move on
    if (SUP6.isFinished) {
      SUP6.setAutoDraw(false);
      SUP6.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function SUP6RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'SUP6' ---
    // get data from SUP6
    const SUP6Response =  SUP6.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(SUP6Response, 'SUP6');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var PreviousMaxDurationReached;
var punt_int1;
var tempo_vd1;
var PreviousMaxDuration;
var PreviousComponents;
function PreviousRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'Previous' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    PreviousClock.reset();
    routineTimer.reset();
    PreviousMaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_vd_3
    punt_int1 = 0;
    tempo_vd1 = t;
    
    previous.reset()
    // setup some python lists for storing info about the mouse_vd_2
    mouse_vd_2.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('Previous.started', globalClock.getTime());
    PreviousMaxDuration = null
    // keep track of which components have finished
    PreviousComponents = [];
    PreviousComponents.push(cerch1_3);
    PreviousComponents.push(rett_2);
    PreviousComponents.push(cerch1_4);
    PreviousComponents.push(previous);
    PreviousComponents.push(feedback_3);
    PreviousComponents.push(rettok_2);
    PreviousComponents.push(ok_4);
    PreviousComponents.push(istr_vd_4);
    PreviousComponents.push(istr_vd_5);
    PreviousComponents.push(istr_vd_6);
    PreviousComponents.push(vd_titolo_2);
    PreviousComponents.push(mouse_vd_2);
    
    for (const thisComponent of PreviousComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var msg1;
function PreviousRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'Previous' ---
    // get current time
    t = PreviousClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_vd_3
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    if (isNaN(previous.rating)) {
        if (_pj.in_es6(group, [1, 3, 5])) {
            msg1 = "Seleziona un valore tra 0 e 100";
        }
        if (_pj.in_es6(group, [2, 4, 6])) {
            msg1 = "Select a value from 0 to 100";
        }
    } else {
        punt_int1 = Number.parseInt(previous.rating);
        if (_pj.in_es6(group, [1, 3, 5])) {
            msg1 = ("Hai selezionato: " + punt_int1);
        }
        if (_pj.in_es6(group, [2, 4, 6])) {
            msg1 = ("You selected: " + punt_int1);
        }
    }
    if ((rettok_2.status === PsychoJS.Status.STARTED)) {
        if (mouse_vd_2.isPressedIn(rettok_2)) {
            continueRoutine = false;
        }
    }
    tempo_vd1 = t;
    
    
    // *cerch1_3* updates
    if (t >= 0.0 && cerch1_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerch1_3.tStart = t;  // (not accounting for frame time here)
      cerch1_3.frameNStart = frameN;  // exact frame index
      
      cerch1_3.setAutoDraw(true);
    }
    
    
    // *rett_2* updates
    if (t >= 0.0 && rett_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rett_2.tStart = t;  // (not accounting for frame time here)
      rett_2.frameNStart = frameN;  // exact frame index
      
      rett_2.setAutoDraw(true);
    }
    
    
    // *cerch1_4* updates
    if (t >= 0.0 && cerch1_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerch1_4.tStart = t;  // (not accounting for frame time here)
      cerch1_4.frameNStart = frameN;  // exact frame index
      
      cerch1_4.setAutoDraw(true);
    }
    
    
    // *previous* updates
    if (t >= 0.0 && previous.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      previous.tStart = t;  // (not accounting for frame time here)
      previous.frameNStart = frameN;  // exact frame index
      
      previous.setAutoDraw(true);
    }
    
    
    if (feedback_3.status === PsychoJS.Status.STARTED){ // only update if being drawn
      feedback_3.setText(msg1, false);
    }
    
    // *feedback_3* updates
    if (t >= 0 && feedback_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      feedback_3.tStart = t;  // (not accounting for frame time here)
      feedback_3.frameNStart = frameN;  // exact frame index
      
      feedback_3.setAutoDraw(true);
    }
    
    
    // *rettok_2* updates
    if ((previous.rating) && rettok_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rettok_2.tStart = t;  // (not accounting for frame time here)
      rettok_2.frameNStart = frameN;  // exact frame index
      
      rettok_2.setAutoDraw(true);
    }
    
    
    // *ok_4* updates
    if ((previous.rating) && ok_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ok_4.tStart = t;  // (not accounting for frame time here)
      ok_4.frameNStart = frameN;  // exact frame index
      
      ok_4.setAutoDraw(true);
    }
    
    
    // *istr_vd_4* updates
    if (t >= 0.0 && istr_vd_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_4.tStart = t;  // (not accounting for frame time here)
      istr_vd_4.frameNStart = frameN;  // exact frame index
      
      istr_vd_4.setAutoDraw(true);
    }
    
    
    // *istr_vd_5* updates
    if (t >= 0.0 && istr_vd_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_5.tStart = t;  // (not accounting for frame time here)
      istr_vd_5.frameNStart = frameN;  // exact frame index
      
      istr_vd_5.setAutoDraw(true);
    }
    
    
    // *istr_vd_6* updates
    if (t >= 0.0 && istr_vd_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_6.tStart = t;  // (not accounting for frame time here)
      istr_vd_6.frameNStart = frameN;  // exact frame index
      
      istr_vd_6.setAutoDraw(true);
    }
    
    
    // *vd_titolo_2* updates
    if (t >= 0.0 && vd_titolo_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      vd_titolo_2.tStart = t;  // (not accounting for frame time here)
      vd_titolo_2.frameNStart = frameN;  // exact frame index
      
      vd_titolo_2.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of PreviousComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function PreviousRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'Previous' ---
    for (const thisComponent of PreviousComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('Previous.stopped', globalClock.getTime());
    // Run 'End Routine' code from code_vd_3
    psychoJS.experiment.addData("tempo_vd1", tempo_vd1);
    
    psychoJS.experiment.addData('previous.response', previous.getRating());
    psychoJS.experiment.addData('previous.rt', previous.getRT());
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = mouse_vd_2.getPos();
    _mouseButtons = mouse_vd_2.getPressed();
    psychoJS.experiment.addData('mouse_vd_2.x', _mouseXYs[0]);
    psychoJS.experiment.addData('mouse_vd_2.y', _mouseXYs[1]);
    psychoJS.experiment.addData('mouse_vd_2.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('mouse_vd_2.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('mouse_vd_2.rightButton', _mouseButtons[2]);
    if (mouse_vd_2.clicked_name.length > 0) {
      psychoJS.experiment.addData('mouse_vd_2.clicked_name', mouse_vd_2.clicked_name[0]);}
    // the Routine "Previous" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var D_VD2MaxDurationReached;
var punt_int16;
var tempo_prob1;
var D_VD2MaxDuration;
var D_VD2Components;
function D_VD2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'D_VD2' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    D_VD2Clock.reset();
    routineTimer.reset();
    D_VD2MaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_vd_4
    punt_int16 = 0;
    tempo_prob1 = t;
    
    previous_2.reset()
    // setup some python lists for storing info about the mouse_vd_3
    mouse_vd_3.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('D_VD2.started', globalClock.getTime());
    D_VD2MaxDuration = null
    // keep track of which components have finished
    D_VD2Components = [];
    D_VD2Components.push(cerch1_5);
    D_VD2Components.push(rett_3);
    D_VD2Components.push(cerch1_6);
    D_VD2Components.push(previous_2);
    D_VD2Components.push(feedback_4);
    D_VD2Components.push(rettok_3);
    D_VD2Components.push(ok_5);
    D_VD2Components.push(istr_vd_7);
    D_VD2Components.push(istr_vd_8);
    D_VD2Components.push(istr_vd_9);
    D_VD2Components.push(vd_titolo_3);
    D_VD2Components.push(mouse_vd_3);
    
    for (const thisComponent of D_VD2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var msg16;
function D_VD2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'D_VD2' ---
    // get current time
    t = D_VD2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_vd_4
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    if (isNaN(previous_2.rating)) {
        if (_pj.in_es6(group, [1, 3, 5])) {
            msg16 = "Seleziona un valore tra 0 e 100";
        } else {
            msg16 = "Select a value from 0 to 100";
        }
    } else {
        punt_int16 = Number.parseInt(previous_2.rating);
        if (_pj.in_es6(group, [1, 3, 5])) {
            msg16 = (("Hai selezionato: " + punt_int16.toString()) + " su 100");
        } else {
            msg16 = (("You selected: " + punt_int16.toString()) + " out of 100");
        }
    }
    if ((rettok_3.status === PsychoJS.Status.STARTED)) {
        if (mouse_vd_3.isPressedIn(rettok_3)) {
            continueRoutine = false;
        }
    }
    tempo_prob1 = t;
    
    
    // *cerch1_5* updates
    if (t >= 0.0 && cerch1_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerch1_5.tStart = t;  // (not accounting for frame time here)
      cerch1_5.frameNStart = frameN;  // exact frame index
      
      cerch1_5.setAutoDraw(true);
    }
    
    
    // *rett_3* updates
    if (t >= 0.0 && rett_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rett_3.tStart = t;  // (not accounting for frame time here)
      rett_3.frameNStart = frameN;  // exact frame index
      
      rett_3.setAutoDraw(true);
    }
    
    
    // *cerch1_6* updates
    if (t >= 0.0 && cerch1_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerch1_6.tStart = t;  // (not accounting for frame time here)
      cerch1_6.frameNStart = frameN;  // exact frame index
      
      cerch1_6.setAutoDraw(true);
    }
    
    
    // *previous_2* updates
    if (t >= 0.0 && previous_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      previous_2.tStart = t;  // (not accounting for frame time here)
      previous_2.frameNStart = frameN;  // exact frame index
      
      previous_2.setAutoDraw(true);
    }
    
    
    if (feedback_4.status === PsychoJS.Status.STARTED){ // only update if being drawn
      feedback_4.setText(msg16, false);
    }
    
    // *feedback_4* updates
    if (t >= 0 && feedback_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      feedback_4.tStart = t;  // (not accounting for frame time here)
      feedback_4.frameNStart = frameN;  // exact frame index
      
      feedback_4.setAutoDraw(true);
    }
    
    
    // *rettok_3* updates
    if ((previous_2.rating) && rettok_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rettok_3.tStart = t;  // (not accounting for frame time here)
      rettok_3.frameNStart = frameN;  // exact frame index
      
      rettok_3.setAutoDraw(true);
    }
    
    
    // *ok_5* updates
    if ((previous_2.rating) && ok_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ok_5.tStart = t;  // (not accounting for frame time here)
      ok_5.frameNStart = frameN;  // exact frame index
      
      ok_5.setAutoDraw(true);
    }
    
    
    // *istr_vd_7* updates
    if (t >= 0.0 && istr_vd_7.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_7.tStart = t;  // (not accounting for frame time here)
      istr_vd_7.frameNStart = frameN;  // exact frame index
      
      istr_vd_7.setAutoDraw(true);
    }
    
    
    // *istr_vd_8* updates
    if (t >= 0.0 && istr_vd_8.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_8.tStart = t;  // (not accounting for frame time here)
      istr_vd_8.frameNStart = frameN;  // exact frame index
      
      istr_vd_8.setAutoDraw(true);
    }
    
    
    // *istr_vd_9* updates
    if (t >= 0.0 && istr_vd_9.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_9.tStart = t;  // (not accounting for frame time here)
      istr_vd_9.frameNStart = frameN;  // exact frame index
      
      istr_vd_9.setAutoDraw(true);
    }
    
    
    // *vd_titolo_3* updates
    if (t >= 0.0 && vd_titolo_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      vd_titolo_3.tStart = t;  // (not accounting for frame time here)
      vd_titolo_3.frameNStart = frameN;  // exact frame index
      
      vd_titolo_3.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of D_VD2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function D_VD2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'D_VD2' ---
    for (const thisComponent of D_VD2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('D_VD2.stopped', globalClock.getTime());
    // Run 'End Routine' code from code_vd_4
    psychoJS.experiment.addData("tempo_prob1", tempo_prob1);
    
    psychoJS.experiment.addData('previous_2.response', previous_2.getRating());
    psychoJS.experiment.addData('previous_2.rt', previous_2.getRT());
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = mouse_vd_3.getPos();
    _mouseButtons = mouse_vd_3.getPressed();
    psychoJS.experiment.addData('mouse_vd_3.x', _mouseXYs[0]);
    psychoJS.experiment.addData('mouse_vd_3.y', _mouseXYs[1]);
    psychoJS.experiment.addData('mouse_vd_3.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('mouse_vd_3.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('mouse_vd_3.rightButton', _mouseButtons[2]);
    if (mouse_vd_3.clicked_name.length > 0) {
      psychoJS.experiment.addData('mouse_vd_3.clicked_name', mouse_vd_3.clicked_name[0]);}
    // the Routine "D_VD2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var D_VD3MaxDurationReached;
var punt_int167;
var tempo_prob2;
var D_VD3MaxDuration;
var D_VD3Components;
function D_VD3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'D_VD3' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    D_VD3Clock.reset();
    routineTimer.reset();
    D_VD3MaxDurationReached = false;
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_vd_5
    punt_int167 = 0;
    tempo_prob2 = t;
    
    previous_3.reset()
    // setup some python lists for storing info about the mouse_vd_4
    mouse_vd_4.clicked_name = [];
    gotValidClick = false; // until a click is received
    psychoJS.experiment.addData('D_VD3.started', globalClock.getTime());
    D_VD3MaxDuration = null
    // keep track of which components have finished
    D_VD3Components = [];
    D_VD3Components.push(cerch1_7);
    D_VD3Components.push(rett_4);
    D_VD3Components.push(cerch1_8);
    D_VD3Components.push(previous_3);
    D_VD3Components.push(feedback_5);
    D_VD3Components.push(rettok_4);
    D_VD3Components.push(ok_6);
    D_VD3Components.push(istr_vd_10);
    D_VD3Components.push(istr_vd_11);
    D_VD3Components.push(istr_vd_12);
    D_VD3Components.push(vd_titolo_4);
    D_VD3Components.push(mouse_vd_4);
    
    for (const thisComponent of D_VD3Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var msg167;
function D_VD3RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'D_VD3' ---
    // get current time
    t = D_VD3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_vd_5
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    if (isNaN(previous_3.rating)) {
        if (_pj.in_es6(group, [1, 3, 5])) {
            msg167 = "Seleziona un valore tra 0 e 100";
        } else {
            msg167 = "Select a value from 0 to 100";
        }
    } else {
        punt_int167 = Number.parseInt(previous_3.rating);
        if (_pj.in_es6(group, [1, 3, 5])) {
            msg167 = (("Hai selezionato: " + punt_int167.toString()) + " su 100");
        } else {
            msg167 = (("You selected: " + punt_int167.toString()) + " out of 100");
        }
    }
    if ((rettok_4.status === PsychoJS.Status.STARTED)) {
        if (mouse_vd_4.isPressedIn(rettok_4)) {
            continueRoutine = false;
        }
    }
    tempo_prob2 = t;
    
    
    // *cerch1_7* updates
    if (t >= 0.0 && cerch1_7.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerch1_7.tStart = t;  // (not accounting for frame time here)
      cerch1_7.frameNStart = frameN;  // exact frame index
      
      cerch1_7.setAutoDraw(true);
    }
    
    
    // *rett_4* updates
    if (t >= 0.0 && rett_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rett_4.tStart = t;  // (not accounting for frame time here)
      rett_4.frameNStart = frameN;  // exact frame index
      
      rett_4.setAutoDraw(true);
    }
    
    
    // *cerch1_8* updates
    if (t >= 0.0 && cerch1_8.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      cerch1_8.tStart = t;  // (not accounting for frame time here)
      cerch1_8.frameNStart = frameN;  // exact frame index
      
      cerch1_8.setAutoDraw(true);
    }
    
    
    // *previous_3* updates
    if (t >= 0.0 && previous_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      previous_3.tStart = t;  // (not accounting for frame time here)
      previous_3.frameNStart = frameN;  // exact frame index
      
      previous_3.setAutoDraw(true);
    }
    
    
    if (feedback_5.status === PsychoJS.Status.STARTED){ // only update if being drawn
      feedback_5.setText(msg167, false);
    }
    
    // *feedback_5* updates
    if (t >= 0 && feedback_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      feedback_5.tStart = t;  // (not accounting for frame time here)
      feedback_5.frameNStart = frameN;  // exact frame index
      
      feedback_5.setAutoDraw(true);
    }
    
    
    // *rettok_4* updates
    if ((previous_3.rating) && rettok_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rettok_4.tStart = t;  // (not accounting for frame time here)
      rettok_4.frameNStart = frameN;  // exact frame index
      
      rettok_4.setAutoDraw(true);
    }
    
    
    // *ok_6* updates
    if ((previous_3.rating) && ok_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ok_6.tStart = t;  // (not accounting for frame time here)
      ok_6.frameNStart = frameN;  // exact frame index
      
      ok_6.setAutoDraw(true);
    }
    
    
    // *istr_vd_10* updates
    if (t >= 0.0 && istr_vd_10.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_10.tStart = t;  // (not accounting for frame time here)
      istr_vd_10.frameNStart = frameN;  // exact frame index
      
      istr_vd_10.setAutoDraw(true);
    }
    
    
    // *istr_vd_11* updates
    if (t >= 0.0 && istr_vd_11.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_11.tStart = t;  // (not accounting for frame time here)
      istr_vd_11.frameNStart = frameN;  // exact frame index
      
      istr_vd_11.setAutoDraw(true);
    }
    
    
    // *istr_vd_12* updates
    if (t >= 0.0 && istr_vd_12.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      istr_vd_12.tStart = t;  // (not accounting for frame time here)
      istr_vd_12.frameNStart = frameN;  // exact frame index
      
      istr_vd_12.setAutoDraw(true);
    }
    
    
    // *vd_titolo_4* updates
    if (t >= 0.0 && vd_titolo_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      vd_titolo_4.tStart = t;  // (not accounting for frame time here)
      vd_titolo_4.frameNStart = frameN;  // exact frame index
      
      vd_titolo_4.setAutoDraw(true);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of D_VD3Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function D_VD3RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'D_VD3' ---
    for (const thisComponent of D_VD3Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('D_VD3.stopped', globalClock.getTime());
    // Run 'End Routine' code from code_vd_5
    psychoJS.experiment.addData("tempo_prob2", tempo_prob2);
    
    psychoJS.experiment.addData('previous_3.response', previous_3.getRating());
    psychoJS.experiment.addData('previous_3.rt', previous_3.getRT());
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = mouse_vd_4.getPos();
    _mouseButtons = mouse_vd_4.getPressed();
    psychoJS.experiment.addData('mouse_vd_4.x', _mouseXYs[0]);
    psychoJS.experiment.addData('mouse_vd_4.y', _mouseXYs[1]);
    psychoJS.experiment.addData('mouse_vd_4.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('mouse_vd_4.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('mouse_vd_4.rightButton', _mouseButtons[2]);
    if (mouse_vd_4.clicked_name.length > 0) {
      psychoJS.experiment.addData('mouse_vd_4.clicked_name', mouse_vd_4.clicked_name[0]);}
    // the Routine "D_VD3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var DE;
var DEClock;
function DERoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'DE' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'DE' ---
    DE = new visual.Survey({
        win: psychoJS.window,
        name: 'DE',
        model: 'DemoE.json',
    });
    DEClock = new util.Clock();
    DE.setAutoDraw(true);
    DE.status = PsychoJS.Status.STARTED;
    DE.isFinished = false;
    DE.tStart = t;  // (not accounting for frame time here)
    DE.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function DERoutineEachFrame() {
  return async function () {
    t = DEClock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if DE is completed, move on
    if (DE.isFinished) {
      DE.setAutoDraw(false);
      DE.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function DERoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'DE' ---
    // get data from DE
    const DEResponse =  DE.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(DEResponse, 'DE');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var YoE;
var YoEClock;
function YoERoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'YoE' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'YoE' ---
    YoE = new visual.Survey({
        win: psychoJS.window,
        name: 'YoE',
        model: 'YoE.json',
    });
    YoEClock = new util.Clock();
    YoE.setAutoDraw(true);
    YoE.status = PsychoJS.Status.STARTED;
    YoE.isFinished = false;
    YoE.tStart = t;  // (not accounting for frame time here)
    YoE.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function YoERoutineEachFrame() {
  return async function () {
    t = YoEClock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if YoE is completed, move on
    if (YoE.isFinished) {
      YoE.setAutoDraw(false);
      YoE.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function YoERoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'YoE' ---
    // get data from YoE
    const YoEResponse =  YoE.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(YoEResponse, 'YoE');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var DI;
var DIClock;
function DIRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'DI' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'DI' ---
    DI = new visual.Survey({
        win: psychoJS.window,
        name: 'DI',
        model: 'demoI.json',
    });
    DIClock = new util.Clock();
    DI.setAutoDraw(true);
    DI.status = PsychoJS.Status.STARTED;
    DI.isFinished = false;
    DI.tStart = t;  // (not accounting for frame time here)
    DI.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function DIRoutineEachFrame() {
  return async function () {
    t = DIClock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if DI is completed, move on
    if (DI.isFinished) {
      DI.setAutoDraw(false);
      DI.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function DIRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'DI' ---
    // get data from DI
    const DIResponse =  DI.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(DIResponse, 'DI');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var YoI;
var YoIClock;
function YoIRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'YoI' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    //--- Starting Routine 'YoI' ---
    YoI = new visual.Survey({
        win: psychoJS.window,
        name: 'YoI',
        model: 'YoI.json',
    });
    YoIClock = new util.Clock();
    YoI.setAutoDraw(true);
    YoI.status = PsychoJS.Status.STARTED;
    YoI.isFinished = false;
    YoI.tStart = t;  // (not accounting for frame time here)
    YoI.frameNStart = frameN;  // exact frame index
    return Scheduler.Event.NEXT;
  }
}


function YoIRoutineEachFrame() {
  return async function () {
    t = YoIClock.getTime();
    frameN = frameN + 1;  // number of completed frames (so 0 is the first frame)
    // if YoI is completed, move on
    if (YoI.isFinished) {
      YoI.setAutoDraw(false);
      YoI.status = PsychoJS.Status.FINISHED;
      // survey routines are not non-slip safe, so reset the non-slip timer
      routineTimer.reset();
      return Scheduler.Event.NEXT;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    return Scheduler.Event.FLIP_REPEAT;
  }
}


function YoIRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'YoI' ---
    // get data from YoI
    const YoIResponse =  YoI.getResponse();
    function addRecursively(resp, name) {
        if (resp.constructor === Object) {
            // if resp is an object, add each part as a column
            for (let subquestion in resp) {
                addRecursively(resp[subquestion], `${name}.${subquestion}`);
            }
        } else {
            psychoJS.experiment.addData(name, resp);
        }
    }
    // recursively add survey responses
    addRecursively(YoIResponse, 'YoI');
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var Ant_lastquestionMaxDurationReached;
var Ant_lastquestionMaxDuration;
var Ant_lastquestionComponents;
function Ant_lastquestionRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'Ant_lastquestion' ---
    t = 0;
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    Ant_lastquestionClock.reset(routineTimer.getTime());
    routineTimer.add(7.000000);
    Ant_lastquestionMaxDurationReached = false;
    // update component parameters for each repeat
    textino.setText(finalT);
    // Run 'Begin Routine' code from code_8
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    if (_pj.in_es6(group, [1, 3, 5])) {
        finalT = "Attendi qualche secondo per essere reindirizzata/o alla pagina finale.";
    } else {
        if (_pj.in_es6(group, [2, 4, 6])) {
            finalT = "Please wait a few seconds to be redirected to the final page.";
        } else {
            throw new ValueError("Gruppo non valido. Inserire un numero tra 1 e 6.");
        }
    }
    
    psychoJS.experiment.addData('Ant_lastquestion.started', globalClock.getTime());
    Ant_lastquestionMaxDuration = null
    // keep track of which components have finished
    Ant_lastquestionComponents = [];
    Ant_lastquestionComponents.push(textino);
    
    for (const thisComponent of Ant_lastquestionComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function Ant_lastquestionRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'Ant_lastquestion' ---
    // get current time
    t = Ant_lastquestionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *textino* updates
    if (t >= 0.0 && textino.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      textino.tStart = t;  // (not accounting for frame time here)
      textino.frameNStart = frameN;  // exact frame index
      
      textino.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 7.0 - psychoJS.window.monitorFramePeriod * 0.75;// most of one frame period left
    if (textino.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      textino.setAutoDraw(false);
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of Ant_lastquestionComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Ant_lastquestionRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'Ant_lastquestion' ---
    for (const thisComponent of Ant_lastquestionComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('Ant_lastquestion.stopped', globalClock.getTime());
    if (Ant_lastquestionMaxDurationReached) {
        Ant_lastquestionClock.add(Ant_lastquestionMaxDuration);
    } else {
        Ant_lastquestionClock.add(7.000000);
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
